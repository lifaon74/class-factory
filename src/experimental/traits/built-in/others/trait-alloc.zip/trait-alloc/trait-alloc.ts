import { CreateAbstractMethodCallError } from '../../../../class-helpers/abstract/create-abstract-method-error';
import { Trait } from '../../../trait/trait-class';

export const ALLOC: unique symbol = Symbol('alloc');

export type TAllocData = object;

export type TAllocResultFromThisAndData<GData extends TAllocData, GThis extends object> = Omit<GThis, keyof GData> & GData;


/**
 * The <Alloc> trait is used to create a new object (or any value), initialized with some data
 */
export abstract class TraitAlloc<GData extends TAllocData, GReturn = unknown> extends Trait {
  [ALLOC](data: GData): GReturn {
    throw CreateAbstractMethodCallError('alloc');
  }
}



export function __alloc__<GData extends TAllocData, GThis extends object, GReturn extends (TAllocResultFromThisAndData<GData, GThis> | unknown)>(data: GData, thisArg: GThis): GReturn {
  return Object.create(Object.getPrototypeOf(thisArg), Object.getOwnPropertyDescriptors(data));
}
