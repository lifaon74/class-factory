import { ALLOC, TAllocData, TAllocResultFromThisAndData, TraitAlloc } from './trait-alloc';

/**
 * An <Alloc> trait which creates an object with the prototype of 'this' as prototype,
 * and reflects 'data' properties on it
 * INFO: use this one if you work with classes (mixTraits)
 */
export abstract class TraitAllocFromThisPrototype<GData extends TAllocData, GThis extends object, GReturn extends (TAllocResultFromThisAndData<GData, GThis> | unknown)> extends TraitAlloc<GData, GReturn> {
  [ALLOC](this: GThis, data: GData): GReturn {
    return Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(data));
  }
}
