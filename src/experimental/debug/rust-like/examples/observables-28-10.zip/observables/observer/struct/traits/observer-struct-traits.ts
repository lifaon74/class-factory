import { Trait } from '../../../../../core/trait-decorator';
import { TGenericObserverStruct, TInferObserverStructGValue } from '../observer-struct';
import { TraitEmit } from '../../../../../build-in/stream/trait-emit/trait-emit';

/** TRAITS **/

@Trait()
export abstract class TraitObserverStructEmit<GSelf extends TGenericObserverStruct> extends TraitEmit<GSelf, TInferObserverStructGValue<GSelf>, void> {
  abstract emit(this: GSelf, value: TInferObserverStructGValue<GSelf>): void;
}
