import { TGenericObserverStruct } from '../observer/struct/observer-struct';
import { TGenericObservableStruct } from '../observable/struct/observable-struct';

export interface IObservableObserver<GObserver extends TGenericObserverStruct, GObservable extends TGenericObservableStruct> {
  readonly observer: GObserver;
  readonly observable: GObservable;
}

export type TGenericObservableObserver = IObservableObserver<TGenericObserverStruct, TGenericObservableStruct>;



