import { Trait } from '../../../../../core/trait-decorator';
import { TGenericObservableStruct, TInferObservableStructGValue } from '../observable-struct';
import { IObserverStruct } from '../../../observer/struct/observer-struct';
import { TGenericObservableObserver } from '../../../observable-observer/observable-observer';

/** TRAITS **/

@Trait()
export abstract class TraitObservableStructIsActive<GSelf extends TGenericObservableStruct> {
  abstract isActive(this: GSelf): boolean;
}

// @Trait()
// export abstract class TraitObservableStructGetObservers<GSelf extends TGenericObservableStruct> {
//   abstract getObservers(this: GSelf): readonly IObserverStruct<TInferObservableStructGValue<GSelf>>[]; // TODO return readonly list
// }

@Trait()
export abstract class TraitObservableStructPipeTo<GSelf extends TGenericObservableStruct> {
  abstract pipeTo<GObserver extends IObserverStruct<TInferObservableStructGValue<GSelf>>>(this: GSelf, observer: GObserver): GObserver; // TODO
  // abstract pipeTo<GCallback extends (value: TInferObservableStructGValue<GSelf>) => void>(this: GSelf, callback: GCallback): any; // TODO
}

@Trait()
export abstract class TraitObservableStructPipeThrough<GSelf extends TGenericObservableStruct> {
  abstract pipeThrough<GObservableObserver extends TGenericObservableObserver>(this: GSelf, observableObserver: GObservableObserver): GObservableObserver['observable']; // TODO
}

@Trait()
export abstract class TraitObservableStructClearObservers<GSelf extends TGenericObservableStruct> {
  abstract clearObservers(this: GSelf): GSelf;
}
