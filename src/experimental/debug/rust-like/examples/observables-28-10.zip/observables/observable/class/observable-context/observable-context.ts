import { Trait } from '../../../../../core/trait-decorator';
import { Impl } from '../../../../../core/implementation-decorator';
import { AssembleTraitImplementations } from '../../../../../core/apply-trait-implementation';
import { CreatePrivateContext } from '../../../../../../../class-helpers/private/create-private-context';
import { IsObject } from '../../../../../../../object-helpers/is-object';
import { HasProperty } from '../../../../../../../object-helpers/object-has-property';
import { TraitEmit } from '../../../../../build-in/stream/trait-emit/trait-emit';
import { IObservableStruct, IsObservableStruct } from '../../struct/observable-struct';

/** PRIVATE CONTEXT **/

export const OBSERVABLE_CONTEXT_PRIVATE_CONTEXT: unique symbol = Symbol('observable-context-private-context');

export interface IObservableContextPrivateContext<GValue> {
  readonly observable: IObservableStruct<GValue>;
}


/** STRUCT DEFINITION **/

export interface IObservableContextStruct<GValue> {
  readonly [OBSERVABLE_CONTEXT_PRIVATE_CONTEXT]: IObservableContextPrivateContext<GValue>;
}

export type TGenericObservableContextStruct = IObservableContextStruct<any>;

export type TInferObservableContextStructGValue<GObservableContextStruct extends TGenericObservableContextStruct> =
  GObservableContextStruct extends IObservableContextStruct<infer GValue>
    ? GValue
    : never;

export function IsObservableContextStruct<GValue>(value: any): value is IObservableContextStruct<GValue> {
  return IsObject(value)
    && HasProperty(value, OBSERVABLE_CONTEXT_PRIVATE_CONTEXT);
}

/** TRAITS **/

@Trait()
export abstract class TraitObservableContextStructGetObservable<GSelf extends TGenericObservableContextStruct> {
  abstract getObservable(this: GSelf): IObservableStruct<TInferObservableContextStructGValue<GSelf>>;
}

@Trait()
export abstract class TraitObservableContextStructEmit<GSelf extends TGenericObservableContextStruct> extends TraitEmit<GSelf, TInferObservableContextStructGValue<GSelf>, void> {
}


/** IMPLEMENTATIONS **/

@Impl()
export class ImplTraitGetObservableForObservableContextStruct<GSelf extends TGenericObservableContextStruct> extends TraitObservableContextStructGetObservable<GSelf> {
  getObservable(this: GSelf): IObservableStruct<TInferObservableContextStructGValue<GSelf>> {
    return this[OBSERVABLE_CONTEXT_PRIVATE_CONTEXT].observable;
  }
}


@Impl()
export class ImplTraitEmitForObservableContextStruct<GSelf extends TGenericObservableContextStruct> extends TraitObservableContextStructEmit<GSelf> {
  emit(this: GSelf, value: TInferObservableContextStructGValue<GSelf>): void {
    throw 'TODO'; // TODO
  }
}

/** FUNCTIONS **/

export function ConstructObservableContext<GValue>(
  instance: IObservableContextStruct<GValue>,
  observable: IObservableStruct<GValue>,
): void {

  if (!IsObservableStruct(observable)) {
    throw new TypeError(`Expected ObservableStruct as input`);
  }

  CreatePrivateContext<IObservableContextPrivateContext<GValue>>(
    OBSERVABLE_CONTEXT_PRIVATE_CONTEXT,
    instance,
    {
      observable
    }
  );
}


/** CLASS **/

export interface IObservableContext<GValue> extends IObservableContextStruct<GValue>,
  ImplTraitGetObservableForObservableContextStruct<IObservableContext<GValue>>,
  ImplTraitEmitForObservableContextStruct<IObservableContext<GValue>>
{
}

export type TGenericObservableContext = IObservableContext<any>;

export interface IAssembledObservableContextImplementations {
  new<GValue>(): IObservableContext<GValue>;
}

export const ObservableContextImplementationsCollection = [
  ImplTraitGetObservableForObservableContextStruct,
  ImplTraitEmitForObservableContextStruct,
];

const AssembledObservableContextImplementations = AssembleTraitImplementations<IAssembledObservableContextImplementations>(ObservableContextImplementationsCollection);

export class ObservableContext<GValue> extends AssembledObservableContextImplementations<GValue> implements IObservableContext<GValue> {
  readonly [OBSERVABLE_CONTEXT_PRIVATE_CONTEXT]: IObservableContextPrivateContext<GValue>;

  constructor(observable: IObservableStruct<GValue>) {
    super();
    ConstructObservableContext(this, observable);
  }
}
