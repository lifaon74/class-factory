import { IObservablePrivateContext, IObservableStruct, OBSERVABLE_PRIVATE_CONTEXT } from '../observable-struct';
import { IObserverStruct } from '../../../observer/struct/observer-struct';

export function LinkObservableWithObserver<GValue>(observable: IObservableStruct<GValue>, observer: IObserverStruct<GValue>): void {
  const context: IObservablePrivateContext<GValue> = observable[OBSERVABLE_PRIVATE_CONTEXT];
  context.observers.push(observer);
  context.onObserveHook(observer);
}

export function UnlinkObservableWithObserver<GValue>(observable: IObservableStruct<GValue>, observer: IObserverStruct<GValue>): void {
  const context: IObservablePrivateContext<GValue> = observable[OBSERVABLE_PRIVATE_CONTEXT];
  context.observers.splice(context.observers.indexOf(observer), 1);
  context.onUnobserveHook(observer);
}


export function ObservableIsFreshlyObserved<GValue>(
  observable: IObservableStruct<GValue>
): boolean {
  return observable[OBSERVABLE_PRIVATE_CONTEXT].observers.length === 1;
}

export function ObservableIsNotObserved<GValue>(
  observable: IObservableStruct<GValue>
): boolean {
  return observable[OBSERVABLE_PRIVATE_CONTEXT].observers.length === 0;
}

