import { IUnstableStruct } from './unstable-struct';

export function ThrowIfInUnstableState(
  input: IUnstableStruct,
): void {
  if (input.unstable) {
    throw new Error(`Unstable state`);
  }
}

export function EnterUnstableState(
  input: IUnstableStruct,
): void {
  ThrowIfInUnstableState(input);
  input.unstable = true;
}

export function LeaveUnstableState<GValue>(
  input: IUnstableStruct,
): void {
  input.unstable = false;
}
