
export interface IUnstableStruct {
  unstable: boolean;
}
