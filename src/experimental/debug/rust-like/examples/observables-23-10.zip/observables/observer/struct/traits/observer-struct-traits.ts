import { Trait } from '../../../../../core/trait-decorator';
import { TGenericObserverStruct, TInferObserverStructGValue } from '../observer-struct';
import { TraitEmit } from '../../../../../build-in/stream/trait-emit/trait-emit';
import { IObservableStruct } from '../../../observable/struct/observable-struct';

/** TRAITS **/

@Trait()
export abstract class TraitObserverStructIsObserving<GSelf extends TGenericObserverStruct> {
  abstract isObserving(this: GSelf): boolean;
}

@Trait()
export abstract class TraitObserverStructGetObservables<GSelf extends TGenericObserverStruct> {
  abstract getObservables(this: GSelf): readonly IObservableStruct<TInferObserverStructGValue<GSelf>>[]; // TODO return readonly list
}

@Trait()
export abstract class TraitObserverStructEmit<GSelf extends TGenericObserverStruct> extends TraitEmit<GSelf, TInferObserverStructGValue<GSelf>, void> {
  abstract emit(this: GSelf, value: TInferObserverStructGValue<GSelf>, observable?: IObservableStruct<TInferObserverStructGValue<GSelf>>): void;
}

@Trait()
export abstract class TraitObserverStructObserve<GSelf extends TGenericObserverStruct> {
  abstract observe<GObservables extends IObservableStruct<TInferObserverStructGValue<GSelf>>[]>(this: GSelf, ...observables: GObservables): GSelf;
}

@Trait()
export abstract class TraitObserverStructUnobserve<GSelf extends TGenericObserverStruct> {
  abstract unobserve<GObservables extends IObservableStruct<TInferObserverStructGValue<GSelf>>[]>(this: GSelf, ...observables: GObservables): GSelf;
}

@Trait()
export abstract class TraitObserverStructDisconnect<GSelf extends TGenericObserverStruct> {
  abstract disconnect(this: GSelf): GSelf;
}
