import { Impl } from '../../../../../core/implementation-decorator';
import {
  OBSERVER_PRIVATE_CONTEXT,
  TGenericObserverStruct,
  TInferObserverStructGValue,
  TObserverPrivateContextFromGSelf,
} from '../observer-struct';
import {
  TraitObserverStructDisconnect,
  TraitObserverStructEmit,
  TraitObserverStructGetObservables,
  TraitObserverStructIsObserving,
  TraitObserverStructObserve,
  TraitObserverStructUnobserve,
} from '../traits/observer-struct-traits';
import { TraitDeactivate } from '../../../../../build-in/activable/trait-deactivate/trait-deactivate';
import {
  TraitToggleUsingActivateAndDeactivate,
  TTraitToggleUsingActivateAndDeactivateGSelfConstraint,
} from '../../../../../build-in/activable/trait-toggle/trait-toggle-using-activate-and-deactivate';
import { TraitActivate } from '../../../../../build-in/activable/trait-activate/trait-activate';
import { TraitIsActivated } from '../../../../../build-in/activable/trait-is-activated/trait-is-activated';
import { IObservableStruct, IsObservableStruct } from '../../../observable/struct/observable-struct';
import {
  LinkObservableWithObserver,
  UnlinkObservableWithObserver,
} from '../../../observable/struct/functions/observable-functions';
import {
  EnterUnstableState,
  LeaveUnstableState,
  ThrowIfInUnstableState,
} from '../../../shared/unstable/unstable-struct-functions';


/** IMPLEMENTATIONS **/

/* PROPERTIES */

@Impl() // non critical
export class ImplTraitIsObservingForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitObserverStructIsObserving<GSelf> {
  isObserving(this: GSelf): boolean {
    return this[OBSERVER_PRIVATE_CONTEXT].observables.length > 0;
  }
}

@Impl()
export class ImplTraitGetObservablesForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitObserverStructGetObservables<GSelf> {
  getObservables(this: GSelf): readonly IObservableStruct<TInferObserverStructGValue<GSelf>>[] {
    return Object.freeze(this[OBSERVER_PRIVATE_CONTEXT].observables.slice(0)); // TODO improve
  }
}

/* ACTIVABLE */

@Impl()
export class ImplTraitIsActivatedForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitIsActivated<GSelf> {
  isActivated(this: GSelf): boolean {
    const context: TObserverPrivateContextFromGSelf<GSelf> = this[OBSERVER_PRIVATE_CONTEXT];
    ThrowIfInUnstableState(context);
    return context.activated;
  }
}

@Impl()
export class ImplTraitActivateForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitActivate<GSelf, GSelf> {
  activate(this: GSelf): GSelf {
    type GValue = TInferObserverStructGValue<GSelf>;
    const context: TObserverPrivateContextFromGSelf<GSelf> = this[OBSERVER_PRIVATE_CONTEXT];
    EnterUnstableState(context);
    if (!context.activated) {
      context.activated = true;
      const observables: IObservableStruct<GValue>[] = context.observables;
      for (let i = 0, l = observables.length; i < l; i++) {
        LinkObservableWithObserver<GValue>(observables[i], this);
      }
    }
    LeaveUnstableState(context);
    return this;
  }
}

@Impl()
export class ImplTraitDeactivateForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitDeactivate<GSelf, GSelf> {
  deactivate(this: GSelf): GSelf {
    type GValue = TInferObserverStructGValue<GSelf>;
    const context: TObserverPrivateContextFromGSelf<GSelf> = this[OBSERVER_PRIVATE_CONTEXT];
    EnterUnstableState(context);
    if (context.activated) {
      context.activated = false;
      const observables: IObservableStruct<GValue>[] = context.observables;
      for (let i = 0, l = observables.length; i < l; i++) {
        UnlinkObservableWithObserver<GValue>(observables[i], this);
      }
    }
    LeaveUnstableState(context);
    return this;
  }
}


export interface TImplTraitToggleForObserverStructGSelfConstraint<GSelf> extends TGenericObserverStruct, TTraitToggleUsingActivateAndDeactivateGSelfConstraint<GSelf> {
}

@Impl() // non critical
export class ImplTraitToggleForObserverStruct<GSelf extends TImplTraitToggleForObserverStructGSelfConstraint<GSelf>> extends TraitToggleUsingActivateAndDeactivate<GSelf> {
}


/* OBSERVER */

@Impl()
export class ImplTraitEmitForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitObserverStructEmit<GSelf> {
  emit(this: GSelf, value: TInferObserverStructGValue<GSelf>, observable?: IObservableStruct<TInferObserverStructGValue<GSelf>>): void {
    const context: TObserverPrivateContextFromGSelf<GSelf> = this[OBSERVER_PRIVATE_CONTEXT];
    ThrowIfInUnstableState(context);
    if (context.activated) {
      context.emit.call(this, value, observable);
    }
  }
}

@Impl()
export class ImplTraitObserveForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitObserverStructObserve<GSelf> {
  observe<GObservables extends IObservableStruct<TInferObserverStructGValue<GSelf>>[]>(this: GSelf, ...observables: GObservables): GSelf {
    type GValue = TInferObserverStructGValue<GSelf>;
    const context: TObserverPrivateContextFromGSelf<GSelf> = this[OBSERVER_PRIVATE_CONTEXT];
    EnterUnstableState(context);
    for (let i = 0, l = observables.length; i < l; i++) {
      const observable: IObservableStruct<GValue> = observables[i];
      if (IsObservableStruct(observable)) {
        if (context.observables.includes(observable)) {
          throw new Error(`Already observing this Observable`);
        } else {
          context.observables.push(observable);
          if (context.activated) {
            LinkObservableWithObserver<GValue>(observables[i], this);
          }
        }
      } else {
        throw new TypeError(`Expected Observable as argument #${ i + 1 } of Observer.observe.`);
      }
    }
    LeaveUnstableState(context);
    return this;
  }
}

@Impl()
export class ImplTraitUnobserveForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitObserverStructUnobserve<GSelf> {
  unobserve<GObservables extends IObservableStruct<TInferObserverStructGValue<GSelf>>[]>(this: GSelf, ...observables: GObservables): GSelf {
    type GValue = TInferObserverStructGValue<GSelf>;
    const context: TObserverPrivateContextFromGSelf<GSelf> = this[OBSERVER_PRIVATE_CONTEXT];
    EnterUnstableState(context);
    for (let i = 0, l = observables.length; i < l; i++) {
      const observable: IObservableStruct<GValue> = observables[i];
      if (IsObservableStruct(observable)) {
        const index: number = context.observables.indexOf(observable);
        if (index === -1) {
          throw new Error(`Not observing this Observable`);
        } else {
          context.observables.splice(index, 1);
          if (context.activated) {
            UnlinkObservableWithObserver<GValue>(observable, this);
          }
        }
      } else {
        throw new TypeError(`Expected Observable as argument #${ i + 1 } of Observer.unobserve.`);
      }
    }
    LeaveUnstableState(context);
    return this;
  }
}

@Impl() // non critical
export class ImplTraitDisconnectForObserverStruct<GSelf extends TGenericObserverStruct> extends TraitObserverStructDisconnect<GSelf> {
  disconnect(this: GSelf): GSelf {
    type GValue = TInferObserverStructGValue<GSelf>;
    const context: TObserverPrivateContextFromGSelf<GSelf> = this[OBSERVER_PRIVATE_CONTEXT];
    EnterUnstableState(context);
    if (context.activated) {
      for (let i = 0, l = context.observables.length; i < l; i++) {
        UnlinkObservableWithObserver<GValue>(context.observables[i], this);
      }
    }
    context.observables.length = 0;
    LeaveUnstableState(context);
    return this;
  }
}
