import {
  IObserverPrivateContext,
  IObserverStruct,
  OBSERVER_PRIVATE_CONTEXT,
  TObserverOnEmitCallBack,
} from '../struct/observer-struct';
import { AssembleTraitImplementations } from '../../../../core/apply-trait-implementation';
import {
  ImplTraitActivateForObserverStruct,
  ImplTraitDeactivateForObserverStruct,
  ImplTraitDisconnectForObserverStruct,
  ImplTraitEmitForObserverStruct,
  ImplTraitGetObservablesForObserverStruct,
  ImplTraitIsActivatedForObserverStruct,
  ImplTraitIsObservingForObserverStruct,
  ImplTraitObserveForObserverStruct,
  ImplTraitToggleForObserverStruct,
  ImplTraitUnobserveForObserverStruct,
} from '../struct/implementations/observer-struct-implementations';
import { CreatePrivateContext } from '../../../../../../class-helpers/private/create-private-context';

/** CONSTRUCTOR **/

export function ConstructObserver<GValue>(
  instance: IObserverStruct<GValue>,
  onEmit: TObserverOnEmitCallBack<GValue>,
): void {
  if (typeof onEmit !== 'function') {
    throw new TypeError(`Expected function as first argument of Observer.`);
  }

  CreatePrivateContext<IObserverPrivateContext<GValue>>(
    OBSERVER_PRIVATE_CONTEXT,
    instance,
    {
      emit: onEmit.bind(instance),
      activated: false,
      observables: [],
      unstable: false,
    },
  );
}

/** CLASS **/

export interface IObserver<GValue> extends IObserverStruct<GValue>,
  ImplTraitIsObservingForObserverStruct<IObserver<GValue>>,
  ImplTraitGetObservablesForObserverStruct<IObserver<GValue>>,
  ImplTraitActivateForObserverStruct<IObserver<GValue>>,
  ImplTraitDeactivateForObserverStruct<IObserver<GValue>>,
  ImplTraitIsActivatedForObserverStruct<IObserver<GValue>>,
  ImplTraitToggleForObserverStruct<IObserver<GValue>>,
  ImplTraitEmitForObserverStruct<IObserver<GValue>>,
  ImplTraitObserveForObserverStruct<IObserver<GValue>>,
  ImplTraitUnobserveForObserverStruct<IObserver<GValue>>,
  ImplTraitDisconnectForObserverStruct<IObserver<GValue>> {
}

export interface IAssembledObserverImplementations {
  new<GValue>(): IObserver<GValue>;
}

export const ObserverImplementationsCollection = [
  ImplTraitIsObservingForObserverStruct,
  ImplTraitGetObservablesForObserverStruct,
  ImplTraitActivateForObserverStruct,
  ImplTraitDeactivateForObserverStruct,
  ImplTraitIsActivatedForObserverStruct,
  ImplTraitToggleForObserverStruct,
  ImplTraitEmitForObserverStruct,
  ImplTraitObserveForObserverStruct,
  ImplTraitUnobserveForObserverStruct,
  ImplTraitDisconnectForObserverStruct,
];
const AssembledObserverImplementations = AssembleTraitImplementations<IAssembledObserverImplementations>(ObserverImplementationsCollection);

export class Observer<GValue> extends AssembledObserverImplementations<GValue> implements IObserver<GValue> {
  readonly [OBSERVER_PRIVATE_CONTEXT]: IObserverPrivateContext<GValue>;

  constructor(onEmit: TObserverOnEmitCallBack<GValue>) {
    super();
    ConstructObserver(this, onEmit);
  }
}
