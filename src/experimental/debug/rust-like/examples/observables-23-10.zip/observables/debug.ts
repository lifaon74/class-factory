import { IObservableContext } from './observable/class/observable-context/observable-context';
import { Observer } from './observer/class/observer-class';
import {
  ObservableIsFreshlyObserved,
  ObservableIsNotObserved,
} from './observable/struct/functions/observable-functions';
import { Observable } from './observable/class/observable-class';

// https://github.com/lifaon74/observables/blob/dev-3.0-ts-4.0-support/src/core/observable/interfaces.ts
// https://github.com/lifaon74/observables/tree/dev-3.0-ts-4.0-support/src/core/observable
// https://github.com/lifaon74/observables/blob/dev-3.0-ts-4.0-support/src/core/observer/implementation.ts

export async function debugObserver1() {

  const observer1 = new Observer<number>((value: number) => {
    console.log('receive', value);
  });

  console.log('isActivated', observer1.isActivated());
  observer1.emit(1);
  observer1.activate();
  console.log('isActivated', observer1.isActivated());
  observer1.emit(2);
}

export async function debugObservable1() {
  console.log('debugObservable');

  const observable1 = new Observable<number>((context: IObservableContext<number>) => {
    let timer: any;
    return {
      onObserved: () => {
        observer1.deactivate();
        console.log('onObserved');
        if (ObservableIsFreshlyObserved(context.getObservable())) {
          timer = setInterval(() => context.emit(Math.random()), 1000)
        }
      },
      onUnobserved: () => {
        console.log('onUnobserved');
        if (ObservableIsNotObserved(context.getObservable())) {
          clearInterval(timer);
        }
      }
    }
  });

  const observer1 = new Observer<number>((value: number) => {
    console.log('receive', value);
  });
  observer1
    .observe(observable1)
    .activate();

  // console.log(observable1);
  console.log(observer1);
}

export async function debugObservable() {
  // await debugObserver1();
  await debugObservable1();
}

