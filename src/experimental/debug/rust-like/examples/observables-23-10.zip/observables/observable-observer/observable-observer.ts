import { IObserverStruct } from '../observer/struct/observer-struct';
import { IObservableStruct } from '../observable/struct/observable-struct';

export interface IObservableObserver<GObserver extends IObserverStruct<any>, GObservable extends IObservableStruct<any>> {
  readonly observer: GObserver;
  readonly observable: GObservable;
}

export type TGenericObservableObserver = IObservableObserver<IObserverStruct<any>, IObservableStruct<any>>;



