import { Impl } from '../../../../../core/implementation-decorator';
import {
  IObservablePrivateContext,
  IObservablePrivateContextWithTypedObservers,
  IObservableStruct,
  IObservableStructWithTypedObservers,
  OBSERVABLE_PRIVATE_CONTEXT,
  TGenericObservableStruct,
  TInferObservableStructGValue,
} from '../observable-struct';
import {
  TraitObservableStructClearObservers,
  TraitObservableStructGetObservers,
  TraitObservableStructIsObserved,
  TraitObservableStructPipeThrough,
  TraitObservableStructPipeTo,
} from '../traits/observable-struct-traits';
import { IObserverStruct, TGenericObserverStruct } from '../../../observer/struct/observer-struct';
import { TGenericObservableObserver } from '../../../observable-observer/observable-observer';
import { TraitActivate } from '../../../../../build-in/activable/trait-activate/trait-activate';
import { TraitDeactivate } from '../../../../../build-in/activable/trait-deactivate/trait-deactivate';
import { TraitIsActivated } from '../../../../../build-in/activable/trait-is-activated/trait-is-activated';
import { TraitObserverStructUnobserve } from '../../../observer/struct/traits/observer-struct-traits';

/** IMPLEMENTATIONS **/

@Impl() // non critical
export class ImplTraitIsObservedForObservableContextStruct<GSelf extends TGenericObservableStruct> extends TraitObservableStructIsObserved<GSelf> {
  isObserved(this: GSelf): boolean {
    return this[OBSERVABLE_PRIVATE_CONTEXT].observers.length > 0;
  }
}

@Impl()
export class ImplTraitGetObserversForObservableContextStruct<GSelf extends TGenericObservableStruct> extends TraitObservableStructGetObservers<GSelf> {
  getObservers(this: GSelf): readonly IObserverStruct<TInferObservableStructGValue<GSelf>>[] {
    return Object.freeze(this[OBSERVABLE_PRIVATE_CONTEXT].observers.slice(0));
  }
}

@Impl() // non critical
export class ImplTraitPipeToForObservableContextStruct<GSelf extends TGenericObservableStruct> extends TraitObservableStructPipeTo<GSelf> {
  pipeTo<GObserver extends IObserverStruct<TInferObservableStructGValue<GSelf>>>(this: GSelf, observer: GObserver): GObserver {
    throw 'TODO'; // TODO
  }
}

@Impl() // non critical
export class ImplTraitPipeThroughForObservableContextStruct<GSelf extends TGenericObservableStruct> extends TraitObservableStructPipeThrough<GSelf> {
  pipeThrough<GObservableObserver extends TGenericObservableObserver>(this: GSelf, observableObserver: GObservableObserver): GObservableObserver['observable'] {
    throw 'TODO'; // TODO
  }
}



// export type A<GObserver extends TGenericObserverStruct> = GObserver & TraitObserverStructUnobserve<GObserver>;
//
// export interface IObserverStructWithUnobserveTrait<GValue> extends IObserverStruct<GValue>, TraitObserverStructUnobserve<GObserver>

export type TImplTraitClearObserversForObservableContextStructUsingUnobserveGSelfConstraint = IObservableStructWithTypedObservers<IObserverStruct<any> & TraitObserverStructUnobserve<IObserverStruct<any>>>;

@Impl() // non critical
export class ImplTraitClearObserversForObservableContextStructUsingUnobserve<GSelf extends TImplTraitClearObserversForObservableContextStructUsingUnobserveGSelfConstraint> extends TraitObservableStructClearObservers<GSelf> {
  clearObservers(this: GSelf): GSelf {
    // const context: IObservablePrivateContextWithTypedObservers<IObserverStructWithUnobserveTrait<TInferObservableStructGValue<GSelf>>> = this[OBSERVABLE_PRIVATE_CONTEXT];
    // while (context.observers.length > 0) {
    //   context.observers[0].unobserve(instance);
    // }
    return this;
  }
}
