import { IObserverStruct, TInferObserverStructGValue } from '../../observer/struct/observer-struct';
import { IsObject } from '../../../../../../object-helpers/is-object';
import { HasProperty } from '../../../../../../object-helpers/object-has-property';

/** TYPES **/

export type TObservableOnObserveHookCallBackWithTypedObserver<GObserver extends IObserverStruct<any>> = (observer: GObserver) => void;
export type TObservableOnUnobserveHookCallBackWithTypedObserver<GObserver extends IObserverStruct<any>> = (observer: GObserver) => void;

export type TObservableOnObserveHookCallBack<GValue> = TObservableOnObserveHookCallBackWithTypedObserver<IObserverStruct<GValue>>;
export type TObservableOnUnobserveHookCallBack<GValue> = TObservableOnUnobserveHookCallBackWithTypedObserver<IObserverStruct<GValue>>;


/** PRIVATE CONTEXT **/

export const OBSERVABLE_PRIVATE_CONTEXT: unique symbol = Symbol('observable-private-context');

export interface IObservablePrivateContextWithTypedObservers<GObserver extends IObserverStruct<any>> {
  readonly observers: GObserver[];
  readonly onObserveHook: TObservableOnObserveHookCallBackWithTypedObserver<GObserver>;
  readonly onUnobserveHook: TObservableOnUnobserveHookCallBackWithTypedObserver<GObserver>;

  // readonly pendingEmit: TInferObserverStructGValue<GObserver>[];
  // emitting: boolean;
}

export interface IObservablePrivateContext<GValue> extends IObservablePrivateContextWithTypedObservers<IObserverStruct<GValue>> {
}


export type TObservablePrivateContextFromGSelf<GSelf extends TGenericObservableStruct> = IObservablePrivateContext<TInferObservableStructGValue<GSelf>>;


/** STRUCT DEFINITION **/

export interface IObservableStructWithTypedObservers<GObserver extends IObserverStruct<any>> {
  readonly [OBSERVABLE_PRIVATE_CONTEXT]: IObservablePrivateContextWithTypedObservers<GObserver>;
}

export interface IObservableStruct<GValue> {
  readonly [OBSERVABLE_PRIVATE_CONTEXT]: IObservablePrivateContext<GValue>;
}

export type TGenericObservableStruct = IObservableStructWithTypedObservers<IObserverStruct<any>>;
// export type TGenericObservableStruct = IObservableStruct<any>;

export type TInferObservableStructGValue<GObservableStruct extends TGenericObservableStruct> =
  GObservableStruct extends IObservableStruct<infer GValue>
    ? GValue
    : never;

export function IsObservableStruct<GValue>(value: any): value is IObservableStruct<GValue> {
  return IsObject(value)
    && HasProperty(value, OBSERVABLE_PRIVATE_CONTEXT);
}
