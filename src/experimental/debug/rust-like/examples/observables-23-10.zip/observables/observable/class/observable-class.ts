import { IsObject } from '../../../../../../object-helpers/is-object';
import { CreatePrivateContext } from '../../../../../../class-helpers/private/create-private-context';
import { AssembleTraitImplementations } from '../../../../core/apply-trait-implementation';
import {
  IObservableContext,
  IObservableContextStruct,
  ObservableContext,
} from './observable-context/observable-context';
import { noop } from '../../../../../../function-helpers/noop';
import { Mutable } from '../../../../../../types/mutable';
import {
  IObservablePrivateContext,
  IObservableStruct,
  OBSERVABLE_PRIVATE_CONTEXT,
  TObservableOnObserveHookCallBack,
  TObservableOnUnobserveHookCallBack,
} from '../struct/observable-struct';
import {
  ImplTraitClearObserversForObservableContextStructUsingUnobserve,
  ImplTraitGetObserversForObservableContextStruct,
  ImplTraitIsObservedForObservableContextStruct,
  ImplTraitPipeThroughForObservableContextStruct,
  ImplTraitPipeToForObservableContextStruct,
} from '../struct/implementations/observable-struct-implementations';


/** OBSERVABLE HOOK **/

export interface IObservableHook<GValue> {
  onObserved?: TObservableOnObserveHookCallBack<GValue>;
  onUnobserved?: TObservableOnUnobserveHookCallBack<GValue>;
}

export type TObservableCreateCallBackWithObservableContextStruct<GValue> = (this: IObservableStruct<GValue>, context: IObservableContextStruct<GValue>) => void;

export type TObservableCreateCallBack<GValue> = (this: IObservableStruct<GValue>, context: IObservableContext<GValue>) => (IObservableHook<GValue> | void);


/** FUNCTIONS **/

export function ConstructObservable<GValue>(
  instance: IObservableStruct<GValue>,
  create?: TObservableCreateCallBack<GValue>,
): void {
  const context: Mutable<IObservablePrivateContext<GValue>> = CreatePrivateContext<IObservablePrivateContext<GValue>>(
    OBSERVABLE_PRIVATE_CONTEXT,
    instance,
    {
      observers: [],
      onObserveHook: noop,
      onUnobserveHook: noop,
      pendingEmit: [],
      emitting: false
    }
  );

  if (typeof create === 'function') {
    const hook: IObservableHook<GValue> | void = create.call(instance, new ObservableContext<GValue>(instance));

    if (hook !== void 0) {
      if (IsObject(hook)) {
        if (typeof hook.onObserved === 'function') {
          context.onObserveHook = hook.onObserved.bind(instance);
        }

        if (typeof hook.onUnobserved === 'function') {
          context.onUnobserveHook = hook.onUnobserved.bind(instance);
        }
      } else {
        throw new TypeError(`Expected object or void as return of ${ instance.constructor.name }'s create function.`);
      }
    }
  } else if (create !== void 0) {
    throw new TypeError(`Expected function or void as ${ instance.constructor.name }'s create function.`);
  }
}

/** CLASS **/

export interface IObservable<GValue> extends IObservableStruct<GValue>,
  ImplTraitIsObservedForObservableContextStruct<IObservable<GValue>>,
  ImplTraitGetObserversForObservableContextStruct<IObservable<GValue>>,
  ImplTraitPipeToForObservableContextStruct<IObservable<GValue>>,
  ImplTraitPipeThroughForObservableContextStruct<IObservable<GValue>>,
ImplTraitClearObserversForObservableContextStructUsingUnobserve<IObservable<GValue>>
{}



export interface IAssembledObservableImplementations {
  new<GValue>(): IObservable<GValue>;
}

export const ObservableImplementationsCollection = [
  ImplTraitIsObservedForObservableContextStruct,
  ImplTraitGetObserversForObservableContextStruct,
  ImplTraitPipeToForObservableContextStruct,
  ImplTraitPipeThroughForObservableContextStruct,
  ImplTraitClearObserversForObservableContextStructUsingUnobserve,
];

const AssembledObservableImplementations = AssembleTraitImplementations<IAssembledObservableImplementations>(ObservableImplementationsCollection);

export class Observable<GValue> extends AssembledObservableImplementations<GValue> implements IObservable<GValue> {
  readonly [OBSERVABLE_PRIVATE_CONTEXT]: IObservablePrivateContext<GValue>;

  constructor(create?: TObservableCreateCallBack<GValue>) {
    super();
    ConstructObservable(this, create);
  }
}
