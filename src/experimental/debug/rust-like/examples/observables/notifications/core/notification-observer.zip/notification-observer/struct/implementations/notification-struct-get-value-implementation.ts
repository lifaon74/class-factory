import {
  NOTIFICATION_PRIVATE_CONTEXT,
  TGenericNotificationStruct,
  TInferNotificationStructGValue,
} from '../notification-observer-struct';
import { Impl } from '../../../../../../../core/implementation-decorator';
import { TraitNotificationObserverGetCallback } from '../../traits/trait-notification-observer-get-callback';


@Impl()
export class ImplTraitGetValueForNotificationStruct<GSelf extends TGenericNotificationStruct> extends TraitNotificationObserverGetCallback<GSelf, TInferNotificationStructGValue<GSelf>> {
  getValue(this: GSelf): TInferNotificationStructGValue<GSelf> {
    return this[NOTIFICATION_PRIVATE_CONTEXT].value;
  }
}
