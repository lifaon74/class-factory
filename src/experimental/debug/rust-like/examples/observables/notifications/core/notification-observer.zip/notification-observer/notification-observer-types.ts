import { TraitIsImplementedBy } from '../../../../../core/trait-is-implemented-by';
import {
  TInferTraitNotificationObserverGetCallbackGCallback,
  TraitNotificationObserverGetCallback,
} from './traits/trait-notification-observer-get-callback';
import {
  TInferTraitNotificationObserverGetNameGName,
  TraitNotificationObserverGetName,
} from './traits/trait-notification-observer-get-name';

export interface INotificationObserverLike<GName extends string, GCallback extends TGenericNotificationObserverCallback> extends TraitNotificationObserverGetName<any, GName>,
  TraitNotificationObserverGetCallback<any, GCallback> {
}

export type TGenericNotificationObserverLike = INotificationObserverLike<any, any>;

export type TInferNotificationObserverLikeGName<GNotificationObserverLike extends TGenericNotificationObserverLike> = TInferTraitNotificationObserverGetNameGName<GNotificationObserverLike>;
export type TInferNotificationObserverLikeGCallback<GNotificationObserverLike extends TGenericNotificationObserverLike> = TInferTraitNotificationObserverGetCallbackGCallback<GNotificationObserverLike>;

export function IsNotificationObserverLike<GName extends string, GCallback extends TGenericNotificationObserverCallback>(value: any): value is INotificationObserverLike<GName, GCallback> {
  return TraitIsImplementedBy(TraitNotificationObserverGetName, value)
    && TraitIsImplementedBy(TraitNotificationObserverGetCallback, value);
}

/*---*/

export type TNotificationObserverCallback<GValue> = (value: GValue) => void;
export type TGenericNotificationObserverCallback = TNotificationObserverCallback<any>;
