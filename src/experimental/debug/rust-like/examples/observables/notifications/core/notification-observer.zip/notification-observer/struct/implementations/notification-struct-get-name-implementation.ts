import {
  NOTIFICATION_PRIVATE_CONTEXT,
  TGenericNotificationStruct,
  TInferNotificationStructGName,
} from '../notification-observer-struct';
import { Impl } from '../../../../../../../core/implementation-decorator';
import { TraitNotificationObserverGetName } from '../../traits/trait-notification-observer-get-name';


@Impl()
export class ImplTraitGetNameForNotificationStruct<GSelf extends TGenericNotificationStruct> extends TraitNotificationObserverGetName<GSelf, TInferNotificationStructGName<GSelf>> {
  getName(this: GSelf): TInferNotificationStructGName<GSelf> {
    return this[NOTIFICATION_PRIVATE_CONTEXT].name;
  }
}
