import { Trait } from '../../../../../../core/trait-decorator';
import { TGenericNotificationObserverCallback } from '../notification-observer-types';


@Trait()
export abstract class TraitNotificationObserverGetCallback<GSelf, GCallback extends TGenericNotificationObserverCallback> {
  abstract getCallback(this: GSelf): GCallback;
}

export type TInferTraitNotificationObserverGetCallbackGCallback<GTrait extends TraitNotificationObserverGetCallback<any, any>> =
  GTrait extends TraitNotificationObserverGetCallback<any, infer GCallback>
    ? GCallback
    : never;
