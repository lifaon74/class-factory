export * from './trait-iterator-some';
export * from './iterator-some';
