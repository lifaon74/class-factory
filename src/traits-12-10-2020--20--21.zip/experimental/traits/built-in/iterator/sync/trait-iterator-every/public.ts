export * from './trait-iterator-every';
export * from './iterator-every';
