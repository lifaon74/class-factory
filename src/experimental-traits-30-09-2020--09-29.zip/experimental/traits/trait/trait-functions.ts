import {
  TGenericTrait,
  TInferTraitPrototype,
  TMethodsFromTrait,
  TMixTraitsInterfaceWithOptionalBaseClass,
  TMixTraitsWithOptionalBaseClass,
  TWithImplementedTrait,
  TWithImplementedTraits,
} from './trait-types';
import {
  ExtractMethodsFromObjectPrototypeChainCached,
  ImplementMethodOnObject,
  MethodOrChildIsImplementedBy,
} from '../method/method-functions';
import { TConstructorOrVoid } from '../../../core/traits/with-this-method/traits/trait-types';
import { IsChildFunctionOf, RegisterChildFunction } from '../../function-helpers/register-child-function';
import { CallFunction } from '../../function-helpers/call-function';
import { TGenericFunction } from '../../types/function-types';
import { ListGlobalVariablesHavingPrototype } from '../../misc/list-global-variables-having-prototype';
import { HasOwnProperty } from '../../object-helpers/object-has-own-property';
import { TGenericMethod } from '../method/method-types';


/**
 * Returns a Map of IMethod built from a Trait
 */
// export function ExtractMethodsFromTrait<GTrait extends TGenericTrait>(trait: GTrait): TMethodMapFromTrait<GTrait> {
//   return ExtractMethodsFromObjectPrototypeChain<TInferTraitPrototype<GTrait>>(trait.prototype);
// }

const EXTRACT_METHODS_FROM_TRAIT_CACHE = new WeakMap<any, readonly any[]>(); // [trait, methods[]]
export function ExtractMethodsFromTraitCached<GTrait extends TGenericTrait>(trait: GTrait): readonly TMethodsFromTrait<GTrait>[] {
  let cached: readonly any[] | undefined = EXTRACT_METHODS_FROM_TRAIT_CACHE.get(trait);

  if (cached === void 0) {
    cached = Object.freeze(Array.from(ExtractMethodsFromObjectPrototypeChainCached<TInferTraitPrototype<GTrait>>(trait.prototype).values()));
    EXTRACT_METHODS_FROM_TRAIT_CACHE.set(trait, cached);
  }

  return cached as readonly TMethodsFromTrait<GTrait>[];
}


/**
 * Implements 'trait' on a 'target'
 */
export function ImplementTraitOnObject<GTrait extends TGenericTrait, GTarget>(
  trait: GTrait,
  target: GTarget,
): TWithImplementedTrait<GTarget, GTrait> {
  type TMethods = TMethodsFromTrait<GTrait>;
  const methods: readonly TMethods[] = ExtractMethodsFromTraitCached<GTrait>(trait);
  for (let i = 0, l = methods.length; i < l; i++) {
    ImplementMethodOnObject<TMethods, GTarget>(methods[i], target);
  }
  return target as TWithImplementedTrait<GTarget, GTrait>;
}

// export function ImplementTrait<GTrait extends TGenericTrait, GTarget>(
//   trait: GTrait,
//   target: GTarget,
// ): TWithImplementedTrait<GTarget, GTrait> {
//   type TMethods = TMethodsFromTrait<GTrait>;
//   const iterator: IterableIterator<TMethods> = ExtractMethodsFromTrait<GTrait>(trait).values();
//   let result: IteratorResult<TMethods>;
//   while (!(result = iterator.next()).done) {
//     ImplementMethodOnObject<TMethods, GTarget>(result.value, target);
//   }
//   return target as TWithImplementedTrait<GTarget, GTrait>;
// }

export function ImplementTraitsOnObject<GTrait extends TGenericTrait, GTarget>(
  traits: readonly GTrait[],
  target: GTarget,
): TWithImplementedTraits<GTarget, GTrait> {
  for (let i = 0, l = traits.length; i < l; i++) {
    ImplementTraitOnObject<GTrait, GTarget>(traits[i], target);
  }
  return target as TWithImplementedTraits<GTarget, GTrait>;
}

/**
 * Returns true if 'trait' or any of its child's traits is implemented by 'target'
 */
export function TraitIsImplementedBy<GTrait extends TGenericTrait, GTarget>(
  trait: GTrait,
  target: GTarget,
): target is TWithImplementedTrait<GTarget, GTrait> {
  type TMethods = TMethodsFromTrait<GTrait>;
  const methods: readonly TMethods[] = ExtractMethodsFromTraitCached<GTrait>(trait);
  for (let i = 0, l = methods.length; i < l; i++) {
    if (!MethodOrChildIsImplementedBy(methods[i], target)) {
      return false;
    }
  }
  return true;
}

const TRAIT_IS_IMPLEMENTED_BY_CACHE = new WeakMap<any, WeakMap<any, boolean>>(); // [target, [trait, implementedBy]]
export function TraitIsImplementedByCached<GTrait extends TGenericTrait, GTarget>(
  trait: GTrait,
  target: GTarget,
): target is TWithImplementedTrait<GTarget, GTrait> {
  let cachedMap: WeakMap<any, boolean> | undefined = TRAIT_IS_IMPLEMENTED_BY_CACHE.get(target);
  // let cached: boolean;
  if (cachedMap === void 0) {
    cachedMap = new WeakMap<any, boolean>();
    TRAIT_IS_IMPLEMENTED_BY_CACHE.set(trait, cachedMap);
  }

  let cached: boolean | undefined = cachedMap.get(trait);

  if (cached === void 0) {
    cached = TraitIsImplementedBy<GTrait, GTarget>(trait, target);
    cachedMap.set(trait, cached);
  }

  return cached as boolean;
}

// export function TraitIsImplementedBy<GTrait extends TGenericTrait, GTarget>(
//   trait: GTrait,
//   target: GTarget,
// ): target is TWithImplementedTrait<GTarget, GTrait> {
//   type TMethods = TMethodsFromTrait<GTrait>;
//   const iterator: Iterator<TMethods> = ExtractMethodsFromTrait<GTrait>(trait).values();
//   let result: IteratorResult<TMethods>;
//   while (!(result = iterator.next()).done) {
//     if (!MethodIsImplementedBy(result.value, target)) {
//       return false;
//     }
//   }
//   return true;
// }




/**
 * Creates a Trait based on the intersection of many other Traits
 */
export function MixTraits<GTraits extends TGenericTrait, GBaseClass extends TConstructorOrVoid>(
  traits: readonly GTraits[],
  baseClass?: GBaseClass,
): TMixTraitsWithOptionalBaseClass<GTraits, GBaseClass> {
  const mixed: TMixTraitsWithOptionalBaseClass<GTraits, GBaseClass> = (
    (baseClass === void 0)
      ? class MixedTraits {
      }
      : // @ts-ignore
      class MixedTraits extends baseClass {
      }
  ) as TMixTraitsWithOptionalBaseClass<GTraits, GBaseClass>;

  // const mixed: TMixTraits<GTraits> = class MixedTrait {
  // } as TMixTraits<GTraits>;
  for (let i = 0, li = traits.length; i < li; i++) {
    ImplementTraitOnObject<TGenericTrait, any>(traits[i], mixed.prototype);
  }
  return mixed;
}


export function MixTraitsInterface<GInterface, GBaseClass extends TConstructorOrVoid>(
  traits: readonly TGenericTrait[],
  baseClass?: GBaseClass,
): TMixTraitsInterfaceWithOptionalBaseClass<GInterface, GBaseClass> {
  return MixTraits<TGenericTrait, GBaseClass>(traits, baseClass);
}



export function CallTraitMethod<GTrait extends TGenericTrait, GPropertyKey extends keyof TInferTraitPrototype<GTrait>>(
  trait: GTrait,
  propertyKey: GPropertyKey,
  thisArgs: TInferTraitPrototype<GTrait>[GPropertyKey] extends (this: infer GThis) => any ? GThis : never,
  args: TInferTraitPrototype<GTrait>[GPropertyKey] extends (...args: infer GArgs) => any ? GArgs : never,
): TInferTraitPrototype<GTrait>[GPropertyKey] extends (...args: any[]) => infer GReturn ? GReturn : never {
  // return trait.prototype[propertyKey].apply(thisArgs, args);
  return CallFunction(trait.prototype[propertyKey], thisArgs, args);
}

export function CallTraitMethodOnObject<GTrait extends TGenericTrait, GPropertyKey extends keyof TInferTraitPrototype<GTrait>>(
  trait: GTrait,
  propertyKey: GPropertyKey,
  thisArgs: TInferTraitPrototype<GTrait>[GPropertyKey] extends (this: infer GThis) => any ? GThis : never,
  args: TInferTraitPrototype<GTrait>[GPropertyKey] extends (...args: infer GArgs) => any ? GArgs : never,
): TInferTraitPrototype<GTrait>[GPropertyKey] extends (...args: any[]) => infer GReturn ? GReturn : never {
  const objectMethod: TGenericFunction = (thisArgs as any)[propertyKey];
  const traitMethod: TGenericFunction = trait.prototype[propertyKey];

  return CallFunction(
    IsChildFunctionOf(objectMethod, traitMethod)
      ? objectMethod
      : traitMethod,
    thisArgs,
    args,
  );
}


export function ExtractTraitMethod<GTrait extends TGenericTrait, GPropertyKey extends keyof TInferTraitPrototype<GTrait>>(
  trait: GTrait,
  propertyKey: GPropertyKey,
): TInferTraitPrototype<GTrait>[GPropertyKey] {
  return trait.prototype[propertyKey];
}



export function RegisterChildTrait(
  childTrait: TGenericTrait,
  parentTrait: TGenericTrait,
): void {
  const childMethods: readonly TGenericMethod[] = ExtractMethodsFromTraitCached<TGenericTrait>(childTrait);
  const parentMethods: readonly TGenericMethod[] = ExtractMethodsFromTraitCached<TGenericTrait>(childTrait);
}

/**
 * TODO improve
 */
export function ReflectTraitOnGlobalVariables<GTrait extends TGenericTrait, GPropertyKey extends keyof TInferTraitPrototype<GTrait>>(
  trait: GTrait,
  propertyKey: GPropertyKey,
): void {
  const traitMethod: TGenericFunction = trait.prototype[propertyKey];
  Array.from(ListGlobalVariablesHavingPrototype()).forEach(([, globalVariable]) => {
    if (HasOwnProperty(globalVariable.prototype, propertyKey)) {
      RegisterChildFunction(globalVariable.prototype[propertyKey], traitMethod);
    }
  })
}
