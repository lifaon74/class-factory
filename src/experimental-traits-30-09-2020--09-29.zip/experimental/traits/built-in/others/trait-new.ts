import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';



export const NEW: unique symbol = Symbol('new');

export abstract class TraitNew<GArgs extends any[], GInstance> {
  [NEW](...args: GArgs): GInstance {
    throw CreateAbstractMethodCallError('new');
  }
}
