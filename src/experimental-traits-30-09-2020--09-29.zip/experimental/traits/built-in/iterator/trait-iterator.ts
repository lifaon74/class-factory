import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';


export abstract class TraitIterator<GValue, GReturn = any, GNext = undefined> implements Iterator<GValue, GReturn, GNext> {
  next(...args: [] | [GNext]): IteratorResult<GValue, GReturn> {
    throw CreateAbstractMethodCallError('next');
  }

  return(value?: GReturn): IteratorResult<GValue, GReturn> {
    throw new ReferenceError('undefined');
  }

  throw(e?: any): IteratorResult<GValue, GReturn> {
    throw new ReferenceError('undefined');
  }
}
