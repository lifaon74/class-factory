import { TraitArrayLike } from './trait-array-like';
import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitArrayEvery<GValue> extends TraitArrayLike<GValue> {
  every(predicate: (value: GValue, index: number, array: this) => boolean): boolean {
    for (let i: number = 0, l = this.length(); i < l; i++) {
      if (!predicate(this.item(i), i, this)) {
        return false;
      }
    }
    return true;
  }
}

