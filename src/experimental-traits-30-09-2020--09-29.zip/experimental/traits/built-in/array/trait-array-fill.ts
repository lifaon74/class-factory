import { TraitArrayLike } from './trait-array-like';
import { mixTraitsInterface } from '../../public';
import { TraitArraySetItem } from './trait-array-set-item';

export function ResolveArrayStartArgument(start: number | undefined, length: number): number {
  return (start === void 0)
    ? 0
    : (
      (start < 0)
        ? Math.max(0, length + start)
        : Math.min(length, start)
    );
}

export function ResolveArrayEndArgument(end: number | undefined, start: number, length: number): number {
  return (end === void 0)
    ? length
    : (
      Math.max(
        start,
        (end < 0)
          ? (length + end)
          : Math.min(length, end),
      )
    );
}


interface ITraitArrayFillSuperTraits<GValue> extends TraitArrayLike<GValue>, TraitArraySetItem<GValue> {
}

export abstract class TraitArrayFill<GValue> extends mixTraitsInterface<ITraitArrayFillSuperTraits<unknown>, void>([TraitArraySetItem, TraitArrayLike]) {
  fill(value: GValue, start?: number, end?: number): this {
    const length: number = this.length();
    let i: number = ResolveArrayStartArgument(start, length);
    const _end: number = ResolveArrayEndArgument(end, i, length);
    for (; i < _end; i++) {
      this.setItem(i, value);
    }
    return this;
  }
}

