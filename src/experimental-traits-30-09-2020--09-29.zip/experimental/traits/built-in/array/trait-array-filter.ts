import { TraitArrayLike } from './trait-array-like';
import { mixTraits } from '../../public';
import { ALLOC, TraitAlloc } from '../others/trait-alloc';
import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitArrayFilter<GValue> extends TraitArrayLike<GValue> {
  filter(predicate: (value: GValue, index: number, array: this) => boolean): this {
    throw CreateAbstractMethodCallError('filter');
  }
}


/*--*/

export abstract class TraitArrayFilterUsingAllocAndNativeArrayFilter<GValue> extends mixTraits([TraitArrayLike, TraitAlloc]) {
  filter(predicate: (value: GValue, index: number, array: this) => boolean): this {
    return this[ALLOC](
      Array.from(this[Symbol.iterator]()).filter(predicate as any, this)
    );
  }
}


/*--*/
// INFO: could use ALLOC and .push too
