import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitAdd<GInput, GOutput> {
  add(value: GInput): GOutput {
    throw CreateAbstractMethodCallError('add');
  }
}
