import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitSubtract<GInput, GOutput> {
  subtract(value: GInput): GOutput {
    throw CreateAbstractMethodCallError('subtract');
  }
}
