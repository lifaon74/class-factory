import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitNegate<GInput, GOutput> {
  negate(): GOutput {
    throw CreateAbstractMethodCallError('negate');
  }
}
