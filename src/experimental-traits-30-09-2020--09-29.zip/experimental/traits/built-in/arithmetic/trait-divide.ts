import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitDivide<GInput, GOutput> {
  divide(value: GInput): GOutput {
    throw CreateAbstractMethodCallError('divide');
  }
}
