import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitMultiply<GInput, GOutput> {
  multiply(value: GInput): GOutput {
    throw CreateAbstractMethodCallError('multiply');
  }
}
