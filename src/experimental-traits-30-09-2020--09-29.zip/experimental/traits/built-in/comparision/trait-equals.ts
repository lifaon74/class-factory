import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitEquals<GInput> {
  equals(value: GInput): boolean {
    throw CreateAbstractMethodCallError('equals');
  }
}
