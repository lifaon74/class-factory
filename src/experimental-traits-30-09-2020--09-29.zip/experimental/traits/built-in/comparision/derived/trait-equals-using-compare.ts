import { TraitEquals } from '../trait-equals';
import { Ordering, TraitCompare } from '../trait-compare';
import { mixTraits } from '../../../public';

export abstract class TraitEqualsUsingCompare<GInput> extends mixTraits([TraitEquals, TraitCompare]) {
  equals(this: TraitCompare<GInput>, value: GInput): boolean {
    return this.compare(value) === Ordering.Equal;
  }
}
