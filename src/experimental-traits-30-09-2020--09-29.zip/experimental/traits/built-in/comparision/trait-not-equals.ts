import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitNotEquals<GInput> {
  notEquals(value: GInput): boolean {
    throw CreateAbstractMethodCallError('notEquals');
  }
}
