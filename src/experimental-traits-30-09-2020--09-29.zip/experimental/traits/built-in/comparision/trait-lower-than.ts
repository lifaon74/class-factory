import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitLowerThan<GInput> {
  lowerThan(value: GInput): boolean {
    throw CreateAbstractMethodCallError('lowerThan');
  }
}
