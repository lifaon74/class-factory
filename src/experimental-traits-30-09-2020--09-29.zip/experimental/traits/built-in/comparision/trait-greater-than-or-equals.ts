import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitGreaterThanOrEquals<GInput> {
  greaterThanOrEquals(value: GInput): boolean {
    throw CreateAbstractMethodCallError('greaterThanOrEquals');
  }
}
