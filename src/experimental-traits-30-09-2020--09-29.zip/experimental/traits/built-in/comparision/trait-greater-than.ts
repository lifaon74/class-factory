import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitGreaterThan<GInput> {
  greaterThan(value: GInput): boolean {
    throw CreateAbstractMethodCallError('greaterThan');
  }
}
