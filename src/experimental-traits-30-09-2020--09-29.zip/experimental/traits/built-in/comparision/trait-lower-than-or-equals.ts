import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';

export abstract class TraitLowerThanOrEquals<GInput> {
  lowerThanOrEquals(value: GInput): boolean {
    throw CreateAbstractMethodCallError('lowerThanOrEquals');
  }
}
