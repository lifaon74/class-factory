import { CreateAbstractMethodCallError } from '../../../class-helpers/abstract/create-abstract-method-error';


export abstract class TraitIterable<GValue> implements Iterable<GValue> {
  [Symbol.iterator](): Iterator<GValue> {
    throw CreateAbstractMethodCallError('[Symbol.iterator]');
  }
}
