import {
  GetOwnPropertyDescriptors,
  TGetOwnPropertyDescriptorsIteratorType,
} from '../../object-helpers/object-get-own-property-descriptors';
import { IsNotReservedPropertyName } from '../../object-helpers/reserved-property-name';
import { IsChildFunctionOf, RegisterChildFunction } from '../../function-helpers/register-child-function';
import { IsNotPrimitivePrototype } from '../../object-helpers/primitive-prototype';
import { TGenericMethod, TMethodMapFromObject, TMethodsFromObject, TWithImplementedMethod } from './method-types';
import { GetPrototypeOf } from '../../object-helpers/object-get-prototype-of';


/**
 * Returns true if 'method' or any of its child's methods is implemented by 'target'
 */
export function MethodOrChildIsImplementedBy<GMethod extends TGenericMethod, GTarget>(
  method: GMethod,
  target: GTarget,
): target is TWithImplementedMethod<GTarget, GMethod> {
  return (typeof target[method.propertyKey] === 'function')
    && IsChildFunctionOf(target[method.propertyKey], method.value);
}

/**
 * Returns true if 'method' or any of it's parent's methods is implemented by 'target'
 */
export function MethodOrParentIsImplementedBy<GMethod extends TGenericMethod, GTarget>(
  method: GMethod,
  target: GTarget,
): target is TWithImplementedMethod<GTarget, GMethod> {
  return (typeof target[method.propertyKey] === 'function')
    && IsChildFunctionOf(method.value, target[method.propertyKey]);
}

/**
 * Implements 'method' on 'target'
 */
export function ImplementMethodOnObject<GMethod extends TGenericMethod, GTarget>(
  method: GMethod,
  target: GTarget,
): TWithImplementedMethod<GTarget, GMethod> {
  // if ((method.propertyKey in target) && !MethodOrParentIsImplementedBy<GMethod, GTarget>(method, target)) {
  //   throw new Error(`The property '${ String(method.propertyKey) }' is already implemented`);
  // } else {
  //   Object.defineProperty(target, method.propertyKey, method);
  // }
  if (method.propertyKey in target) {
    if (method !== target[method.propertyKey]) {
      if (typeof target[method.propertyKey] === 'function') {
        if (IsChildFunctionOf(method.value, target[method.propertyKey])) {
          Object.defineProperty(target, method.propertyKey, method);
        } else if (!IsChildFunctionOf(target[method.propertyKey], method.value)) {
          throw new Error(`The property '${ String(method.propertyKey) }' is already implemented`);
        }
      } else {
        throw new Error(`The property '${ String(method.propertyKey) }' is already implemented`);
      }
    }
  } else {
    Object.defineProperty(target, method.propertyKey, method);
  }
  return target as TWithImplementedMethod<GTarget, GMethod>;
}

// /**
//  * Iterates over the own methods of 'target'
//  */
// export function ForEachObjectOwnMethods<GTarget>(
//   target: GTarget,
//   callback: (...args: TGetOwnPropertyDescriptorsIteratorType<GTarget>) => void,
// ): void {
//   const iterator: Iterator<TGetOwnPropertyDescriptorsIteratorType<GTarget>> = GetOwnPropertyDescriptors<GTarget>(target);
//   let result: IteratorResult<TGetOwnPropertyDescriptorsIteratorType<GTarget>>;
//   while (!(result = iterator.next()).done) {
//     const [propertyKey, descriptor]: TGetOwnPropertyDescriptorsIteratorType<GTarget> = result.value;
//     if (IsNotReservedPropertyName(propertyKey)) {
//       if (typeof descriptor.value === 'function') {
//         callback(propertyKey, descriptor, target);
//       } else {
//         throw new Error(`Found property which is not a function: '${ String(propertyKey) }'`);
//       }
//     }
//   }
// }

// /**
//  * Returns a Map of IMethod built from an object
//  * INFO: assumes we explore the prototype chain from deepest to closest
//  */
// export function ExtractObjectOwnMethodsBottomUp<GTarget>(
//   target: GTarget,
//   parentMethodsMap: TMethodMapFromObject<GTarget>,
// ): TMethodMapFromObject<GTarget> {
//   ForEachObjectOwnMethods<GTarget>(target, (propertyKey: keyof GTarget, descriptor: PropertyDescriptor) => {
//     const parentMethod = parentMethodsMap.get(propertyKey);
//     if (parentMethod !== void 0) {
//       RegisterChildFunction(descriptor.value, parentMethod.value);
//     }
//     parentMethodsMap.set(
//       propertyKey,
//       {
//         propertyKey,
//         ...descriptor,
//       } as TMethodsFromObject<GTarget>,
//     );
//   });
//   return parentMethodsMap;
// }
//
// /**
//  * Returns a Map of IMethod built from an object
//  */
// export function ExtractObjectOwnMethods<GTarget>(
//   target: GTarget,
// ): TMethodMapFromObject<GTarget> {
//   const methodsMap: TMethodMapFromObject<GTarget> = new Map<keyof GTarget, TMethodsFromObject<GTarget>>();
//   ForEachObjectOwnMethods(target, (propertyKey: keyof GTarget, descriptor: PropertyDescriptor) => {
//     methodsMap.set(
//       propertyKey,
//       {
//         propertyKey,
//         ...descriptor,
//       } as TMethodsFromObject<GTarget>,
//     );
//   });
//   return methodsMap;
// }
//
//

/**
 * Returns a Map of IMethod built from an object, and its prototype chain
 */
// export function ExtractMethodsFromObjectPrototypeChain<GTarget>(target: GTarget): TMethodMapFromObject<GTarget> {
//   // get the list of all the non primitive prototypes of 'target'
//   const prototypes = Array.from(GetPrototypesChain(target)).filter(IsNotPrimitivePrototype);
//   const methodsMap = new Map<keyof GTarget, TMethodsFromObject<GTarget>>();
//   // extract the methods of each prototypes, starting from the deepest
//   for (let i = prototypes.length - 1; i >= 0; i--) {
//     ExtractObjectOwnMethodsBottomUp<GTarget>(prototypes[i], methodsMap);
//   }
//   return methodsMap;
// }


const EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE = new WeakMap<any, Map<PropertyKey, TGenericMethod>>(); // [target, methodsMap]
export function ExtractMethodsFromObjectPrototypeChainCached<GTarget>(
  target: GTarget,
): TMethodMapFromObject<GTarget> {
  type TPropertyKeys = keyof GTarget;
  type TMethods = TMethodsFromObject<GTarget>;
  type TPropertyKeysAndMethodsTuple = [TPropertyKeys, TMethods];


  let cached: Map<PropertyKey, TGenericMethod> | undefined = EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE.get(target);

  if (cached === void 0) {
    const methodsMap: TMethodMapFromObject<GTarget> = new Map<TPropertyKeys, TMethods>();

    // 1) extract own methods
    const iterator: Iterator<TGetOwnPropertyDescriptorsIteratorType<GTarget>> = GetOwnPropertyDescriptors<GTarget>(target);
    let result: IteratorResult<TGetOwnPropertyDescriptorsIteratorType<GTarget>>;
    while (!(result = iterator.next()).done) {
      const [propertyKey, descriptor]: TGetOwnPropertyDescriptorsIteratorType<GTarget> = result.value;
      if (IsNotReservedPropertyName(propertyKey)) {
        if (typeof descriptor.value === 'function') {
          methodsMap.set(propertyKey, {
            propertyKey,
            ...descriptor,
          } as TMethods);
        } else if (IsNotPrimitivePrototype(target)) {
          throw new Error(`Found property which is not a function: '${ String(propertyKey) }'`);
        }
      }
    }

    // 2) merge with parent proto
    const parent = GetPrototypeOf(target);
    if ((parent !== null) && IsNotPrimitivePrototype(parent)) {
      const parentMethodsMap: TMethodMapFromObject<GTarget> = ExtractMethodsFromObjectPrototypeChainCached<GTarget>(GetPrototypeOf(target));

      const iterator: Iterator<TPropertyKeysAndMethodsTuple> = parentMethodsMap.entries();
      let result: IteratorResult<TPropertyKeysAndMethodsTuple>;
      while (!(result = iterator.next()).done) {
        const [propertyKey, parentMethod]: TPropertyKeysAndMethodsTuple = result.value;
        const method: TMethods | undefined = methodsMap.get(propertyKey);
        if (method === void 0) {
          methodsMap.set(propertyKey, parentMethod);
        } else {
          RegisterChildFunction(method.value, parentMethod.value);
        }
      }
    }

    cached = methodsMap;
    EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE.set(target, cached);
  }

  return cached as TMethodMapFromObject<GTarget>;
}

// const EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE = new WeakMap<any, Map<PropertyKey, TGenericMethod>>(); // [target, methodsMap]
// export function ExtractMethodsFromObjectPrototypeChainCached<GTarget>(
//   target: GTarget,
// ): TMethodMapFromObject<GTarget> {
//   type TPropertyKeys = keyof GTarget;
//   type TMethods = TMethodsFromObject<GTarget>;
//   type TPropertyKeysAndMethodsTuple = [TPropertyKeys, TMethods];
//
//
//   let cached: Map<PropertyKey, TGenericMethod> | undefined = EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE.get(target);
//
//   if (cached === void 0) {
//     const methodsMap: TMethodMapFromObject<GTarget> = new Map<TPropertyKeys, TMethods>();
//
//     // 1) extract own methods
//     const iterator: Iterator<TGetOwnPropertyDescriptorsIteratorType<GTarget>> = GetOwnPropertyDescriptors<GTarget>(target);
//     let result: IteratorResult<TGetOwnPropertyDescriptorsIteratorType<GTarget>>;
//     while (!(result = iterator.next()).done) {
//       const [propertyKey, descriptor]: TGetOwnPropertyDescriptorsIteratorType<GTarget> = result.value;
//       if (IsNotReservedPropertyName(propertyKey)) {
//         if (typeof descriptor.value === 'function') {
//           methodsMap.set(propertyKey, {
//             propertyKey,
//             ...descriptor,
//           } as TMethods);
//         } else if (IsNotPrimitivePrototype(target)) {
//           throw new Error(`Found property which is not a function: '${ String(propertyKey) }'`);
//         }
//       }
//     }
//
//     // 2) merge with parent proto
//     const parent = GetPrototypeOf(target);
//     if (parent !== null) {
//       const isNotPrimitiveParent: boolean = IsNotPrimitivePrototype(parent);
//       const parentMethodsMap: TMethodMapFromObject<GTarget> = ExtractMethodsFromObjectPrototypeChainCached<GTarget>(GetPrototypeOf(target));
//
//       const iterator: Iterator<TPropertyKeysAndMethodsTuple> = parentMethodsMap.entries();
//       let result: IteratorResult<TPropertyKeysAndMethodsTuple>;
//       while (!(result = iterator.next()).done) {
//         const [propertyKey, parentMethod]: TPropertyKeysAndMethodsTuple = result.value;
//         const method: TMethods | undefined = methodsMap.get(propertyKey);
//         if (method === void 0) {
//           if (isNotPrimitiveParent) {
//             methodsMap.set(propertyKey, parentMethod);
//           }
//         } else {
//           RegisterChildFunction(method.value, parentMethod.value, isNotPrimitiveParent);
//         }
//       }
//     }
//
//     cached = methodsMap;
//     EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE.set(target, cached);
//   }
//
//   return cached as TMethodMapFromObject<GTarget>;
// }


// const EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE = new WeakMap<any, Map<PropertyKey, TGenericMethod>>(); // [target, methodsMap]
// export function ExtractMethodsFromObjectPrototypeChainCached<GTarget>(
//   target: GTarget,
//   childMethodsMap: TMethodMapFromObject<GTarget> = new Map<keyof GTarget, TMethodsFromObject<GTarget>>(),
// ): TMethodMapFromObject<GTarget> {
//   type TPropertyKeys = keyof GTarget;
//   type TMethods = TMethodsFromObject<GTarget>;
//   type TPropertyKeysAndMethodsTuple = [TPropertyKeys, TMethods];
//
//
//   let cached: Map<PropertyKey, TGenericMethod> | undefined = EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE.get(target);
//
//   if (cached === void 0) {
//     const methodsMap: TMethodMapFromObject<GTarget> = new Map<TPropertyKeys, TMethods>();
//
//     const iterator: Iterator<TGetOwnPropertyDescriptorsIteratorType<GTarget>> = GetOwnPropertyDescriptors<GTarget>(target);
//     let result: IteratorResult<TGetOwnPropertyDescriptorsIteratorType<GTarget>>;
//     while (!(result = iterator.next()).done) {
//       const [propertyKey, descriptor]: TGetOwnPropertyDescriptorsIteratorType<GTarget> = result.value;
//       if (IsNotReservedPropertyName(propertyKey)) {
//         if (typeof descriptor.value === 'function') {
//           const method = {
//             propertyKey,
//             ...descriptor,
//           } as TMethods;
//
//           methodsMap.set(propertyKey, method);
//
//           const childMethod: TGenericMethod | undefined = childMethodsMap.get(propertyKey);
//           if (childMethod !== void 0) {
//             console.log('child method', childMethod.value, descriptor.value);
//             RegisterChildFunction(childMethod.value, descriptor.value);
//           }
//           childMethodsMap.set(propertyKey, method);
//         } else {
//           throw new Error(`Found property which is not a function: '${ String(propertyKey) }'`);
//         }
//       }
//     }
//
//     const parent = GetPrototypeOf(target);
//     if (parent !== null) {
//       if (IsPrimitivePrototype(parent)) { // handle the case of primitive parent
//         const iterator: Iterator<TPropertyKeysAndMethodsTuple> = childMethodsMap.entries();
//         let result: IteratorResult<TPropertyKeysAndMethodsTuple>;
//         while (!(result = iterator.next()).done) {
//           const [propertyKey, childMethod]: TPropertyKeysAndMethodsTuple = result.value;
//           if (HasProperty(parent, propertyKey)) {
//             if (typeof parent[propertyKey] === 'function') {
//               RegisterChildFunction(childMethod.value, parent[propertyKey]);
//             } else {
//               throw new Error(`The property '${ String(propertyKey) }' is not a function on the parent ${ parent.constructor.name }`);
//             }
//           }
//         }
//       } else {
//         const parentMethodsMap: TMethodMapFromObject<GTarget> = ExtractMethodsFromObjectPrototypeChainCached<GTarget>(GetPrototypeOf(target), childMethodsMap);
//
//         const iterator: Iterator<TPropertyKeysAndMethodsTuple> = parentMethodsMap.entries();
//         let result: IteratorResult<TPropertyKeysAndMethodsTuple>;
//         while (!(result = iterator.next()).done) {
//           const [propertyKey, method]: TPropertyKeysAndMethodsTuple = result.value;
//           if (!methodsMap.has(propertyKey)) {
//             methodsMap.set(propertyKey, method);
//           }
//         }
//       }
//     }
//
//     cached = methodsMap;
//     EXTRACT_METHODS_FROM_OBJECT_PROTOTYPE_CHAIN_CACHE.set(target, cached);
//   }
//
//   return cached as TMethodMapFromObject<GTarget>;
// }

