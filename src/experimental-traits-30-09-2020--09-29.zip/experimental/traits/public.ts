
/**
 * A Trait is expressed only through an object (a class)
 * A Trait may extend another
 * A Trait only contain methods
 */

export {
  ImplementTraitOnObject as implementTrait,
  ImplementTraitsOnObject as implementTraits,
  TraitIsImplementedBy as traitIsImplementedBy,
  TraitIsImplementedByCached as traitIsImplementedByCached,
  MixTraits as mixTraits,
  MixTraitsInterface as mixTraitsInterface,
  CallTraitMethod as callTraitMethod,
  CallTraitMethodOnObject as callTraitMethodOnObject
} from './trait/trait-functions';


// /**
//  * Implements 'trait' on a 'target'
//  */
// export function implementTrait<GTrait extends TGenericTrait, GTarget>(
//   trait: GTrait,
//   target: GTarget,
// ): TWithImplementedTrait<GTarget, GTrait> {
//   return ImplementTraitOnObjectCached<GTrait, GTarget>(trait, target);
// }
//
// /**
//  * Returns true if 'trait' or any of its child's traits is implemented by 'target'
//  */
// export function traitIsImplementedBy<GTrait extends TGenericTrait, GTarget>(
//   trait: GTrait,
//   target: GTarget,
// ): target is TWithImplementedTrait<GTarget, GTrait> {
//   return TraitIsImplementedByCached<GTrait, GTarget>(trait, target);
// }
//
// /**
//  * Creates a Trait based on the intersection of many other Traits
//  */
// export function mixTraits<GTraits extends TGenericTrait, GBaseClass extends TConstructorOrVoid>(
//   traits: readonly GTraits[],
//   baseClass?: GBaseClass,
// ): TMixTraitsWithOptionalBaseClass<GTraits, GBaseClass> {
//   return MixTraitsCached<GTraits, GBaseClass>(traits, baseClass);
// }
