export interface Constructor<Instance = any, Args extends any[] = any[]> extends Function {
  new(...args: Args): Instance;
}

export interface HavingPrototype<Instance = any> {
  prototype: Instance;
}

export interface AbstractClass<Instance = any> extends Function, HavingPrototype {
}

export type ClassType<Instance = any> = AbstractClass<Instance> | Constructor<Instance>;

export type TFactory = <TBase extends Constructor>(superClass: TBase) => TBase;

// exclude the constructor from T
export type ExcludeConstructor<T> = {
  [P in keyof T]: T[P] extends new(...args: any[]) => any ? never : T[P];
};


export type TMakeTypedConstructor<GTypedInstance, Args extends any[], GConstructor extends Constructor<GTypedInstance, Args>> =
  ExcludeConstructor<GConstructor>
  & {
  new(...args: Args): GTypedInstance;
}

export type TBaseClassIsUndefinedOrVoid<GBaseClass extends (Constructor | void | undefined)> =
  [void] extends [GBaseClass]
    ? true
    : (
      [undefined] extends [GBaseClass]
        ? true
        : false
      );
