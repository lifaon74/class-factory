

// export function CreateSymbolBasedPrivateProperty<GValue>(
//   name: string,
// ): [symb: unique symbol, set: (target: any, value: GValue) => void, get: (target: any) => GValue] {
//   const _symbol: unique symbol = Symbol(name);
//   return [
//     _symbol,
//     (target: any, value: GValue): void => {
//       target[_symbol]
//     },
//     (target: any): GValue => {
//
//     }
//   ]
// }
