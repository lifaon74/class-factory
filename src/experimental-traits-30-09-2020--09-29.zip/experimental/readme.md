
An object which carries its methods (functions)

VS

Functions only




