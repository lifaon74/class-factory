import { TGenericFunction } from '../../types/misc-types';
import { IImplementForOptions } from './derived-function';

// export interface ITraitFunctionStruct<GPropertyKey extends PropertyKey, GFunction extends TGenericFunction> extends IImplementForOptions {
//   fnc: GFunction;
//   propertyKey: GPropertyKey;
// }

export type TSingleTrait<GPropertyKey extends PropertyKey, GFunction extends TGenericFunction> = [fnc: GFunction, propertyKey: GPropertyKey];

