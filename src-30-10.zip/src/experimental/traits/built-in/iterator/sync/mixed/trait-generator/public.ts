export * from './trait-generator';
