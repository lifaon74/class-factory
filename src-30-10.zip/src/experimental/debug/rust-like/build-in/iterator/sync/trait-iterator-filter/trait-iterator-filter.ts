import { Trait } from '../../../../core/trait-decorator';
import {
  TGenericTraitIteratorNext,
  TInferTraitIteratorNextGNext,
  TInferTraitIteratorNextGValue,
  TraitIteratorNext,
} from '../trait-iterator-next/trait-iterator-next';
import { TIteratorFilterCallback } from './iterator-filter';

@Trait()
export abstract class TraitIteratorFilter<GSelf extends TGenericTraitIteratorNext> {
  abstract filter(
    this: GSelf,
    callback: TIteratorFilterCallback<TInferTraitIteratorNextGValue<GSelf>>,
  ): TraitIteratorNext<any, TInferTraitIteratorNextGValue<GSelf>, void, TInferTraitIteratorNextGNext<GSelf>>;
}
