import { Trait } from '../../../../core/trait-decorator';
import { TIteratorMapCallback } from './iterator-map';
import {
  TGenericTraitIteratorNext, TInferTraitIteratorNextGNext,
  TInferTraitIteratorNextGValue,
  TraitIteratorNext,
} from '../trait-iterator-next/trait-iterator-next';

@Trait()
export abstract class TraitIteratorMap<GSelf extends TGenericTraitIteratorNext> {
  abstract map<GMappedValue>(
    this: GSelf,
    callback: TIteratorMapCallback<TInferTraitIteratorNextGValue<GSelf>, GMappedValue>,
  ): TraitIteratorNext<any, GMappedValue, void, TInferTraitIteratorNextGNext<GSelf>>;
}
