export type IteratorDefaultGReturn = any;

export type IteratorDefaultGNext = undefined;

export interface TIterable<GValue, GReturn, GNext> {
  [Symbol.iterator](): Iterator<GValue, GReturn, GNext>;
}

export type TGenericIterable = TIterable<any, any, any>;

export type TInferIterableGValue<GIterable extends TGenericIterable> =
  GIterable extends TIterable<infer GValue, any, any>
    ? GValue
    : never;

export type TInferIterableGReturn<GIterable extends TGenericIterable> =
  GIterable extends TIterable<any, infer GReturn, any>
    ? GReturn
    : never;

export type TInferIterableGNext<GIterable extends TGenericIterable> =
  GIterable extends TIterable<any, any, infer GNext>
    ? GNext
    : never;
