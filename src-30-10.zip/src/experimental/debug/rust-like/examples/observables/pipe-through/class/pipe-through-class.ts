import {
  IPipeThroughPrivateContext,
  IPipeThroughStruct,
  PIPE_THROUGH_PRIVATE_CONTEXT,
} from '../struct/pipe-through-struct';
import { AssembleTraitImplementations } from '../../../../core/apply-trait-implementation';
import { CreatePrivateContext } from '../../../../../../class-helpers/private/create-private-context';
import { IsObservableLike, TGenericObservableLike } from '../../observable/observable-types';
import {
  ImplTraitActivateForPipeThroughStruct,
  ImplTraitDeactivateForPipeThroughStruct,
  ImplTraitIsActivatedForPipeThroughStruct,
  ImplTraitToggleForPipeThroughStruct,
} from '../struct/implementations/pipe-through-struct-implementations';
import { TPipeThroughObservableObserverConstraint } from '../pipe-through-types';
import { Subscription } from '../../subscription/class/subscription-class';
import { ImplTraitGetObservableForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-get-observable-implementation';

/** CONSTRUCTOR **/

export function ConstructPipeThrough<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>>(
  instance: IPipeThroughStruct<GObservable, GObservableObserver>,
  observable: GObservable,
  observableObserver: GObservableObserver,
): void {
  if (!IsObservableLike(observable)) {
    throw new TypeError(`The argument 'observable' is not an Observable.`);
  }

  CreatePrivateContext<IPipeThroughPrivateContext<GObservable, GObservableObserver>>(
    PIPE_THROUGH_PRIVATE_CONTEXT,
    instance,
    {
      observable: observableObserver.observable,
      subscription: new Subscription<GObservable, GObservableObserver['observer']>(observable, observableObserver.observer),
      undo: null,
    },
  );
}

/** CLASS **/

export interface IPipeThrough<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>> extends IPipeThroughStruct<GObservable, GObservableObserver>,
  ImplTraitGetObservableForPipeThroughStruct<IPipeThrough<GObservable, GObservableObserver>>,
  ImplTraitIsActivatedForPipeThroughStruct<IPipeThrough<GObservable, GObservableObserver>>,
  ImplTraitActivateForPipeThroughStruct<IPipeThrough<GObservable, GObservableObserver>>,
  ImplTraitDeactivateForPipeThroughStruct<IPipeThrough<GObservable, GObservableObserver>>,
  ImplTraitToggleForPipeThroughStruct<IPipeThrough<GObservable, GObservableObserver>> {
}

export interface IAssembledPipeThroughImplementations {
  new<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>>(): IPipeThrough<GObservable, GObservableObserver>;
}

export const PipeThroughImplementationsCollection = [
  ImplTraitGetObservableForPipeThroughStruct,
  ImplTraitIsActivatedForPipeThroughStruct,
  ImplTraitActivateForPipeThroughStruct,
  ImplTraitDeactivateForPipeThroughStruct,
  ImplTraitToggleForPipeThroughStruct,
];

const AssembledPipeThroughImplementations = AssembleTraitImplementations<IAssembledPipeThroughImplementations>(PipeThroughImplementationsCollection);

export class PipeThrough<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>> extends AssembledPipeThroughImplementations<GObservable, GObservableObserver> implements IPipeThrough<GObservable, GObservableObserver> {
  readonly [PIPE_THROUGH_PRIVATE_CONTEXT]: IPipeThroughPrivateContext<GObservable, GObservableObserver>;

  constructor(
    observable: GObservable,
    observableObserver: GObservableObserver,
  ) {
    super();
    ConstructPipeThrough<GObservable, GObservableObserver>(this, observable, observableObserver);
  }
}
