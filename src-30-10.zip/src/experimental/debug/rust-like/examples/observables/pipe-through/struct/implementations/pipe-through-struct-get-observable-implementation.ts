import { Impl } from '../../../../../core/implementation-decorator';
import {
  PIPE_THROUGH_PRIVATE_CONTEXT,
  TGenericPipeThroughStruct,
  TInferPipeThroughStructGObservableObserver,
} from '../pipe-through-struct';
import { TraitPipeThroughGetObservable } from '../../traits/trait-pipe-through-get-observable';

@Impl()
export class ImplTraitGetObservableForPipeThroughStruct<GSelf extends TGenericPipeThroughStruct> extends TraitPipeThroughGetObservable<GSelf, TInferPipeThroughStructGObservableObserver<GSelf>['observable']> {
  getObservable(this: GSelf): TInferPipeThroughStructGObservableObserver<GSelf>['observable'] {
    return this[PIPE_THROUGH_PRIVATE_CONTEXT].observable;
  }
}
