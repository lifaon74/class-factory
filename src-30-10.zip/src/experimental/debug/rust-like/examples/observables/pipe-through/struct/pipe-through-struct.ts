import { IsObject } from '../../../../../../object-helpers/is-object';
import { HasProperty } from '../../../../../../object-helpers/object-has-property';
import { TGenericObservableLike } from '../../observable/observable-types';
import { ISubscriptionLike } from '../../subscription/subscription-types';
import { TPipeThroughObservableObserverConstraint } from '../pipe-through-types';

/** PRIVATE CONTEXT **/

export const PIPE_THROUGH_PRIVATE_CONTEXT: unique symbol = Symbol('pipe-through-private-context');

export interface IPipeThroughPrivateContext<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>> {
  readonly observable: GObservableObserver['observable'];
  subscription: ISubscriptionLike<GObservable, GObservableObserver['observer']>;
  undo: (() => void) | null;
}

export type TPipeThroughPrivateContextFromGSelf<GSelf extends TGenericPipeThroughStruct> = IPipeThroughPrivateContext<TInferPipeThroughStructGObservable<GSelf>, TInferPipeThroughStructGObservableObserver<GSelf>>;


/** STRUCT DEFINITION **/

export interface IPipeThroughStruct<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>> {
  readonly [PIPE_THROUGH_PRIVATE_CONTEXT]: IPipeThroughPrivateContext<GObservable, GObservableObserver>;
}

export type TGenericPipeThroughStruct = IPipeThroughStruct<any, any>;

export type TInferPipeThroughStructGObservable<GPipeThroughStruct extends TGenericPipeThroughStruct> =
  GPipeThroughStruct extends IPipeThroughStruct<infer GObservable, any>
    ? GObservable
    : never;

export type TInferPipeThroughStructGObservableObserver<GPipeThroughStruct extends TGenericPipeThroughStruct> =
  GPipeThroughStruct extends IPipeThroughStruct<infer GObservable, infer GObservableObserver>
    ? (
      GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>
        ? GObservableObserver
        : never
      )
    : never;

export function IsPipeThroughStruct<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>>(value: any): value is IPipeThroughStruct<GObservable, GObservableObserver> {
  return IsObject(value)
    && HasProperty(value, PIPE_THROUGH_PRIVATE_CONTEXT);
}
