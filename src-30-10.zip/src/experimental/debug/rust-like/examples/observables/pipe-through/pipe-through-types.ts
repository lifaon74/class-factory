import { TraitIsImplementedBy } from '../../../core/trait-is-implemented-by';
import { TGenericObservableLike, TInferObservableLikeGObserver } from '../observable/observable-types';
import { IActivableLike, IsActivableLike } from '../../activable/activable-types';
import { TInferTraitGetObservableGObservable } from '../traits/trait-get-observable';
import { IObservableObserver } from '../observable-observer/observable-observer';
import { TraitPipeThroughGetObservable } from './traits/trait-pipe-through-get-observable';

export type TPipeThroughObservableObserverConstraint<GObservable extends TGenericObservableLike> = IObservableObserver<TInferObservableLikeGObserver<GObservable>, TGenericObservableLike>;

export interface TPipeThroughLike<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>> extends IActivableLike<TPipeThroughLike<GObservable, GObservableObserver>>,
  TraitPipeThroughGetObservable<any, GObservableObserver['observable']> {
}

export type TGenericPipeThroughLike = TPipeThroughLike<any, any>;

export type TInferPipeThroughLikeGObservable<GPipeThroughLike extends TGenericPipeThroughLike> = TInferTraitGetObservableGObservable<GPipeThroughLike>;

export function IsPipeThroughLike<GObservable extends TGenericObservableLike, GObservableObserver extends TPipeThroughObservableObserverConstraint<GObservable>>(value: any): value is TPipeThroughLike<GObservable, GObservableObserver> {
  return TraitIsImplementedBy(TraitPipeThroughGetObservable, value)
    && IsActivableLike(value);
}
