import { Impl } from '../../../../../core/implementation-decorator';
import {
  PIPE_THROUGH_PRIVATE_CONTEXT,
  TGenericPipeThroughStruct,
  TPipeThroughPrivateContextFromGSelf,
} from '../pipe-through-struct';
import { TraitIsActivated } from '../../../../../build-in/activable/trait-is-activated/trait-is-activated';
import { TraitActivate } from '../../../../../build-in/activable/trait-activate/trait-activate';
import { TraitDeactivate } from '../../../../../build-in/activable/trait-deactivate/trait-deactivate';
import {
  TraitToggleUsingActivateAndDeactivate,
  TTraitToggleUsingActivateAndDeactivateGSelfConstraint,
} from '../../../../../build-in/activable/trait-toggle/trait-toggle-using-activate-and-deactivate';


/** IMPLEMENTATIONS **/


@Impl()
export class ImplTraitIsActivatedForPipeThroughStruct<GSelf extends TGenericPipeThroughStruct> extends TraitIsActivated<GSelf> {
  isActivated(this: GSelf): boolean {
    return this[PIPE_THROUGH_PRIVATE_CONTEXT].undo !== null;
  }
}

@Impl()
export class ImplTraitActivateForPipeThroughStruct<GSelf extends TGenericPipeThroughStruct> extends TraitActivate<GSelf, GSelf> {
  activate(this: GSelf): GSelf {
    const context: TPipeThroughPrivateContextFromGSelf<GSelf> = this[PIPE_THROUGH_PRIVATE_CONTEXT];
    if (context.undo === null) {
      const undoActiveListener = context.observable.on('active', () => context.subscription.activate());
      const undoInactiveListener = context.observable.on('inactive', () => context.subscription.deactivate());
      context.undo = () => {
        undoActiveListener();
        undoInactiveListener();
      };
      if (context.observable.isActive()) {
        context.subscription.activate();
      }
    }
    return this;
  }
}


@Impl()
export class ImplTraitDeactivateForPipeThroughStruct<GSelf extends TGenericPipeThroughStruct> extends TraitDeactivate<GSelf, GSelf> {
  deactivate(this: GSelf): GSelf {
    const context: TPipeThroughPrivateContextFromGSelf<GSelf> = this[PIPE_THROUGH_PRIVATE_CONTEXT];
    if (context.undo !== null) {
      context.undo();
      context.undo = null;
    }
    return this;
  }
}


export interface ImplTraitToggleForPipeThroughStructGSelfConstraint<GSelf extends TGenericPipeThroughStruct> extends TGenericPipeThroughStruct, TTraitToggleUsingActivateAndDeactivateGSelfConstraint<GSelf> {
}

@Impl()
export class ImplTraitToggleForPipeThroughStruct<GSelf extends ImplTraitToggleForPipeThroughStructGSelfConstraint<GSelf>> extends TraitToggleUsingActivateAndDeactivate<GSelf> {
}
