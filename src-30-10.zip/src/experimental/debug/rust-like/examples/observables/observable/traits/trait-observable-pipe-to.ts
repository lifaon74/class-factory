import { Trait } from '../../../../core/trait-decorator';
import { TGenericObservableLike, TInferObservableLikeGObserver } from '../observable-types';
import { TObserverEmitFunction } from '../../observer/struct/observer-struct';
import { TInferObserverLikeGValue } from '../../observer/observer-types';
import { ISubscriptionLike } from '../../subscription/subscription-types';
import { Observer } from '../../observer/class/observer-class';
import { Subscription } from '../../subscription/class/subscription-class';

@Trait()
export abstract class TraitObservablePipeTo<GSelf extends TGenericObservableLike> {
  pipeTo<GCallback extends TObserverEmitFunction<TInferObserverLikeGValue<TInferObservableLikeGObserver<GSelf>>>>(callback: GCallback): ISubscriptionLike<GSelf, TInferObservableLikeGObserver<GSelf>>;
  pipeTo<GArgObserver extends TInferObservableLikeGObserver<GSelf>>(observer: GArgObserver): ISubscriptionLike<GSelf, GArgObserver>;
  pipeTo(this: GSelf, observerOrCallback: any): ISubscriptionLike<GSelf, TInferObservableLikeGObserver<GSelf>> {
    const observer: TInferObservableLikeGObserver<GSelf> = (typeof observerOrCallback === 'function')
      ? new Observer<any>(observerOrCallback)
      : observerOrCallback;
    return new Subscription<GSelf, TInferObservableLikeGObserver<GSelf>>(this, observer);
  }
}
