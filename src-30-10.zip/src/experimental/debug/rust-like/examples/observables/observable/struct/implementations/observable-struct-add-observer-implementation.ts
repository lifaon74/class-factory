import {
  OBSERVABLE_PRIVATE_CONTEXT,
  TGenericObservableStruct,
  TInferObservableStructGObserver,
} from '../observable-struct';
import { TObservableWithDispatch } from '../../observable-types';
import { Impl } from '../../../../../core/implementation-decorator';
import { TraitObservableAddObserver } from '../../traits/trait-observable-add-observer';
import { IsObserverLike, TGenericObserverLike } from '../../../observer/observer-types';

export interface TImplTraitAddObserverForObservableContextStructGSelfConstraint<GSelf extends TGenericObservableStruct> extends TGenericObservableStruct,
  TObservableWithDispatch<GSelf> {
}

@Impl()
export class ImplTraitAddObserverForObservableContextStruct<GSelf extends TImplTraitAddObserverForObservableContextStructGSelfConstraint<GSelf>> extends TraitObservableAddObserver<GSelf, TInferObservableStructGObserver<GSelf>> {
  addObserver(this: GSelf, observer: TInferObservableStructGObserver<GSelf>): GSelf {
    if (IsObserverLike(observer)) {
      const observers: TGenericObserverLike[] = this[OBSERVABLE_PRIVATE_CONTEXT].observers;
      observers.push(observer);
      this.dispatch('add-observer', observer);
      if (observers.length === 1) {
        this.dispatch('active', void 0);
      }
      return this;
    } else {
      throw new TypeError(`Not an Observer`);
    }
  }
}
