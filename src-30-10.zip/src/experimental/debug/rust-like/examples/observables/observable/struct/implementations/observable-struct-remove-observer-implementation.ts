import { Impl } from '../../../../../core/implementation-decorator';
import { TraitObservableRemoveObserver } from '../../traits/trait-observable-remove-observer';
import {
  OBSERVABLE_PRIVATE_CONTEXT,
  TGenericObservableStruct,
  TInferObservableStructGObserver,
} from '../observable-struct';
import { TGenericObserverLike } from '../../../observer/observer-types';
import { TObservableWithDispatch } from '../../observable-types';

export interface TImplTraitRemoveObserverForObservableContextStructGSelfConstraint<GSelf extends TGenericObservableStruct> extends TGenericObservableStruct,
  TObservableWithDispatch<GSelf> {
}

@Impl()
export class ImplTraitRemoveObserverForObservableContextStruct<GSelf extends TImplTraitRemoveObserverForObservableContextStructGSelfConstraint<GSelf>> extends TraitObservableRemoveObserver<GSelf, TInferObservableStructGObserver<GSelf>> {
  removeObserver(this: GSelf, observer: TInferObservableStructGObserver<GSelf>): GSelf {
    const observers: TGenericObserverLike[] = this[OBSERVABLE_PRIVATE_CONTEXT].observers;
    const index: number = observers.indexOf(observer);
    if (index === -1) {
      throw new Error(`Doesn't contain this Observer`);
    } else {
      observers.splice(index, 1);
      this.dispatch('remove-observer', observer);
      if (observers.length === 0) {
        this.dispatch('inactive', void 0);
      }
    }
    return this;
  }
}
