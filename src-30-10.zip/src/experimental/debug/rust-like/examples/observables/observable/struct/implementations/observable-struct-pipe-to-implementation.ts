import { Impl } from '../../../../../core/implementation-decorator';
import { TGenericObservableLike } from '../../observable-types';
import { TraitObservablePipeTo } from '../../traits/trait-observable-pipe-to';

@Impl()
export class ImplTraitObservablePipeToForObservableContextStruct<GSelf extends TGenericObservableLike> extends TraitObservablePipeTo<GSelf> {
}
