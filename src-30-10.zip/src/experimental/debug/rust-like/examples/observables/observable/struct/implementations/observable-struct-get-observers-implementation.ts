// @Impl()
// export class ImplTraitGetObserversForObservableContextStruct<GSelf extends TGenericObservableStruct> extends TraitObservableStructGetObservers<GSelf> {
//   getObservers(this: GSelf): readonly IObserverStruct<TInferObservableStructGValue<GSelf>>[] {
//     return Object.freeze(this[OBSERVABLE_PRIVATE_CONTEXT].observers.slice(0));
//   }
// }


