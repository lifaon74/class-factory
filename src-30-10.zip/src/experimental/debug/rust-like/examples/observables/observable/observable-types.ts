import { TGenericObserverLike } from '../observer/observer-types';
import { TraitIsImplementedBy } from '../../../core/trait-is-implemented-by';
import { TraitObservableIsActive } from './traits/trait-observable-is-active';
import {
  TInferTraitObservableAddObserverGObserver,
  TraitObservableAddObserver,
} from './traits/trait-observable-add-observer';
import { TraitObservableRemoveObserver } from './traits/trait-observable-remove-observer';
import {
  IObservableStructEventMap,
  TGenericObservableStruct,
  TInferObservableStructGObserver,
} from './struct/observable-struct';
import { TraitEventListenerDispatch } from '../../../build-in/event-listener/sync/trait-event-listener-dispatch/trait-event-listener-dispatch';

export interface IObservableLike<GObserver extends TGenericObserverLike> extends TraitObservableIsActive<IObservableLike<GObserver>>,
  TraitObservableAddObserver<IObservableLike<GObserver>, GObserver>,
  TraitObservableRemoveObserver<IObservableLike<GObserver>, GObserver> {
}


export type TGenericObservableLike = IObservableLike<any>;

export type TInferObservableLikeGObserver<GObservableLike extends TGenericObservableLike> = TInferTraitObservableAddObserverGObserver<GObservableLike>;

export function IsObservableLike<GObserver extends TGenericObserverLike>(value: any): value is IObservableLike<GObserver> {
  return TraitIsImplementedBy(TraitObservableIsActive, value)
    && TraitIsImplementedBy(TraitObservableAddObserver, value)
    && TraitIsImplementedBy(TraitObservableRemoveObserver, value);
}


/** EXTRA **/

export type TObservableWithDispatch<GSelf extends TGenericObservableStruct> = TraitEventListenerDispatch<GSelf, IObservableStructEventMap<TInferObservableStructGObserver<GSelf>>>;
