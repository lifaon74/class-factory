// import { Observer } from './observer/class/observer-class';
// import { debugObservableUsingClasses } from './debug-class';
import { IObservable, Observable, TObservableEmitFunctionFromObserver } from './observable/class/observable-class';
import { IObserverLike } from './observer/observer-types';

// https://github.com/lifaon74/observables/blob/dev-3.0-ts-4.0-support/src/core/observable/interfaces.ts
// https://github.com/lifaon74/observables/tree/dev-3.0-ts-4.0-support/src/core/observable
// https://github.com/lifaon74/observables/blob/dev-3.0-ts-4.0-support/src/core/observer/implementation.ts


class TimerObservable extends Observable<IObserverLike<void>> {
  readonly timeout: number;

  protected _timer: any | null;

  constructor(timeout: number) {
    type GObserver = IObserverLike<void>;

    super((emit: TObservableEmitFunctionFromObserver<GObserver>, observable: IObservable<GObserver>) => {
      observable.on('active', () => {
        console.log('start timer');
        this._timer = setInterval(emit, this.timeout);
      });
      observable.on('inactive', () => {
        console.log('clear timer');
        clearInterval(this._timer);
      });
    });
    this.timeout = timeout;
    this._timer = null;
  }
}


/*-----*/

export async function debugObservableUsingTraits1() {
  console.log('hello');

  // const timer = (timeout: number) => {
  //   return new Observable<Observer<number>>((emit) => {
  //     setInterval(() => emit(Math.random()), timeout);
  //   });
  // }

  const timer = (timeout: number) => new TimerObservable(timeout);

  // const observer = new Observer<number>((value: number) => {
  //   console.log(value);
  // });
  //
  // const observable = timer(1000);
  //
  // const sub = new Subscription(observable, observer);
  // sub.activate();

  // TODO => implement pipeThrough method

  const sub = timer(1000)
    .pipeTo((value: void) => {
      console.log('receive', value);
    })
    .activate();

  // const a = new PipeThrough(timer(1000), { observer: new Observer<void>(() => {}), observable: new Observable<Observer<number>>()})

  (window as any).sub = sub;
}

export async function debugObservableUsingTraits() {
  await debugObservableUsingTraits1();
}

export async function debugObservable() {
  // await debugObservableUsingClasses();
  await debugObservableUsingTraits();
}

