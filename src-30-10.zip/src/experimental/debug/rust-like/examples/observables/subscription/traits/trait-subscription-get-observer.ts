import { Trait } from '../../../../core/trait-decorator';
import { TInferTraitGetObserverGObserver, TraitGetObserver } from '../../traits/trait-get-observer';
import { TGenericObserverLike } from '../../observer/observer-types';

@Trait()
export abstract class TraitSubscriptionGetObserver<GSelf, GObserver extends TGenericObserverLike> extends TraitGetObserver<GSelf, GObserver> {
}

export type TInferTraitSubscriptionGetObserverGValue<GTrait extends TraitSubscriptionGetObserver<any, any>> = TInferTraitGetObserverGObserver<GTrait>;
