import { Impl } from '../../../../../core/implementation-decorator';
import {
  SUBSCRIPTION_PRIVATE_CONTEXT,
  TGenericSubscriptionStruct,
  TSubscriptionPrivateContextFromGSelf,
} from '../subscription-struct';
import { TraitDeactivate } from '../../../../../build-in/activable/trait-deactivate/trait-deactivate';

@Impl()
export class ImplTraitDeactivateForSubscriptionStruct<GSelf extends TGenericSubscriptionStruct> extends TraitDeactivate<GSelf, GSelf> {
  deactivate(this: GSelf): GSelf {
    const context: TSubscriptionPrivateContextFromGSelf<GSelf> = this[SUBSCRIPTION_PRIVATE_CONTEXT];
    if (context.activated) {
      context.activated = false;
      context.observable.removeObserver(context.observer);
    }
    return this;
  }
}
