import { IsObject } from '../../../../../../object-helpers/is-object';
import { HasProperty } from '../../../../../../object-helpers/object-has-property';
import { TGenericObservableLike, TInferObservableLikeGObserver } from '../../observable/observable-types';

/** PRIVATE CONTEXT **/

export const SUBSCRIPTION_PRIVATE_CONTEXT: unique symbol = Symbol('subscription-private-context');

export interface ISubscriptionPrivateContext<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>> {
  readonly observable: GObservable;
  readonly observer: GObserver;
  activated: boolean;
}

export type TSubscriptionPrivateContextFromGSelf<GSelf extends TGenericSubscriptionStruct> = ISubscriptionPrivateContext<TInferSubscriptionStructGObservable<GSelf>, TInferSubscriptionStructGObserver<GSelf>>;


/** STRUCT DEFINITION **/

export interface ISubscriptionStruct<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>> {
  readonly [SUBSCRIPTION_PRIVATE_CONTEXT]: ISubscriptionPrivateContext<GObservable, GObserver>;
}

export type TGenericSubscriptionStruct = ISubscriptionStruct<any, any>;

export type TInferSubscriptionStructGObservable<GSubscriptionStruct extends TGenericSubscriptionStruct> =
  GSubscriptionStruct extends ISubscriptionStruct<infer GObservable, any>
    ? GObservable
    : never;

export type TInferSubscriptionStructGObserver<GSubscriptionStruct extends TGenericSubscriptionStruct> =
  GSubscriptionStruct extends ISubscriptionStruct<infer GObservable, infer GObserver>
    ? (
      GObserver extends TInferObservableLikeGObserver<GObservable>
        ? GObserver
        : never
      )
    : never;

export function IsSubscriptionStruct<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>>(value: any): value is ISubscriptionStruct<GObservable, GObserver> {
  return IsObject(value)
    && HasProperty(value, SUBSCRIPTION_PRIVATE_CONTEXT);
}
