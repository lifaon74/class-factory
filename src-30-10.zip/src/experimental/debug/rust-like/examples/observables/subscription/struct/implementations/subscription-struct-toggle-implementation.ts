import { Impl } from '../../../../../core/implementation-decorator';
import { TGenericSubscriptionStruct } from '../subscription-struct';
import {
  TraitToggleUsingActivateAndDeactivate,
  TTraitToggleUsingActivateAndDeactivateGSelfConstraint,
} from '../../../../../build-in/activable/trait-toggle/trait-toggle-using-activate-and-deactivate';


export interface ImplTraitToggleForSubscriptionStructGSelfConstraint<GSelf extends TGenericSubscriptionStruct> extends TGenericSubscriptionStruct, TTraitToggleUsingActivateAndDeactivateGSelfConstraint<GSelf> {
}

@Impl()
export class ImplTraitToggleForSubscriptionStruct<GSelf extends ImplTraitToggleForSubscriptionStructGSelfConstraint<GSelf>> extends TraitToggleUsingActivateAndDeactivate<GSelf> {
}

