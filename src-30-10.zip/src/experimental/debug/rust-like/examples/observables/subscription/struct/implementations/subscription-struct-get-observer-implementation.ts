import { Impl } from '../../../../../core/implementation-decorator';
import {
  SUBSCRIPTION_PRIVATE_CONTEXT,
  TGenericSubscriptionStruct,
  TInferSubscriptionStructGObserver,
} from '../subscription-struct';
import { TraitSubscriptionGetObserver } from '../../traits/trait-subscription-get-observer';

@Impl()
export class ImplTraitGetObserverForSubscriptionStruct<GSelf extends TGenericSubscriptionStruct> extends TraitSubscriptionGetObserver<GSelf, TInferSubscriptionStructGObserver<GSelf>> {
  getObserver(this: GSelf): TInferSubscriptionStructGObserver<GSelf> {
    return this[SUBSCRIPTION_PRIVATE_CONTEXT].observer;
  }
}
