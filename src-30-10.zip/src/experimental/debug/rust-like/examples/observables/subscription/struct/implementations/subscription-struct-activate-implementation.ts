import { Impl } from '../../../../../core/implementation-decorator';
import {
  SUBSCRIPTION_PRIVATE_CONTEXT,
  TGenericSubscriptionStruct,
  TSubscriptionPrivateContextFromGSelf,
} from '../subscription-struct';
import { TraitActivate } from '../../../../../build-in/activable/trait-activate/trait-activate';

@Impl()
export class ImplTraitActivateForSubscriptionStruct<GSelf extends TGenericSubscriptionStruct> extends TraitActivate<GSelf, GSelf> {
  activate(this: GSelf): GSelf {
    const context: TSubscriptionPrivateContextFromGSelf<GSelf> = this[SUBSCRIPTION_PRIVATE_CONTEXT];
    if (!context.activated) {
      context.activated = true;
      context.observable.addObserver(context.observer);
    }
    return this;
  }
}
