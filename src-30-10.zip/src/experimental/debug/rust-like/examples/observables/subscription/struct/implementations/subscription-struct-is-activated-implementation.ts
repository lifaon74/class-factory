import { Impl } from '../../../../../core/implementation-decorator';
import { SUBSCRIPTION_PRIVATE_CONTEXT, TGenericSubscriptionStruct } from '../subscription-struct';
import { TraitIsActivated } from '../../../../../build-in/activable/trait-is-activated/trait-is-activated';

@Impl()
export class ImplTraitIsActivatedForSubscriptionStruct<GSelf extends TGenericSubscriptionStruct> extends TraitIsActivated<GSelf> {
  isActivated(this: GSelf): boolean {
    return this[SUBSCRIPTION_PRIVATE_CONTEXT].activated;
  }
}
