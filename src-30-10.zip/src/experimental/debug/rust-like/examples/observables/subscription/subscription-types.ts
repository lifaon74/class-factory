import { TraitIsImplementedBy } from '../../../core/trait-is-implemented-by';
import { TGenericObservableLike, TInferObservableLikeGObserver } from '../observable/observable-types';
import { IActivableLike, IsActivableLike } from '../../activable/activable-types';
import { TInferTraitGetObserverGObserver } from '../traits/trait-get-observer';
import { TInferTraitGetObservableGObservable } from '../traits/trait-get-observable';
import { TraitSubscriptionGetObservable } from './traits/trait-subscription-get-observable';
import { TraitSubscriptionGetObserver } from './traits/trait-subscription-get-observer';

export interface ISubscriptionLike<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>> extends IActivableLike<ISubscriptionLike<GObservable, GObserver>>,
  TraitSubscriptionGetObservable<ISubscriptionLike<GObservable, GObserver>, GObservable>,
  TraitSubscriptionGetObserver<ISubscriptionLike<GObservable, GObserver>, GObserver> {
}

export type TGenericSubscriptionLike = ISubscriptionLike<any, any>;

export type TInferSubscriptionLikeGObservable<GSubscriptionLike extends TGenericSubscriptionLike> = TInferTraitGetObservableGObservable<GSubscriptionLike>;
export type TInferSubscriptionLikeGObserver<GSubscriptionLike extends TGenericSubscriptionLike> = TInferTraitGetObserverGObserver<GSubscriptionLike>;

export function IsSubscriptionLike<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>>(value: any): value is ISubscriptionLike<GObservable, GObserver> {
  return TraitIsImplementedBy(TraitSubscriptionGetObservable, value)
    && TraitIsImplementedBy(TraitSubscriptionGetObserver, value)
    && IsActivableLike(value);
}
