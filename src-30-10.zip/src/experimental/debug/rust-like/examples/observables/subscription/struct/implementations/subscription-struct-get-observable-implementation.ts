import { Impl } from '../../../../../core/implementation-decorator';
import {
  SUBSCRIPTION_PRIVATE_CONTEXT,
  TGenericSubscriptionStruct,
  TInferSubscriptionStructGObservable,
} from '../subscription-struct';
import { TraitSubscriptionGetObservable } from '../../traits/trait-subscription-get-observable';


@Impl()
export class ImplTraitGetObservableForSubscriptionStruct<GSelf extends TGenericSubscriptionStruct> extends TraitSubscriptionGetObservable<GSelf, TInferSubscriptionStructGObservable<GSelf>> {
  getObservable(this: GSelf): TInferSubscriptionStructGObservable<GSelf> {
    return this[SUBSCRIPTION_PRIVATE_CONTEXT].observable;
  }
}
