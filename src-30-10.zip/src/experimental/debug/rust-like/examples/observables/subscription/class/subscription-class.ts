import {
  ISubscriptionPrivateContext,
  ISubscriptionStruct,
  SUBSCRIPTION_PRIVATE_CONTEXT,
} from '../struct/subscription-struct';
import { AssembleTraitImplementations } from '../../../../core/apply-trait-implementation';
import { CreatePrivateContext } from '../../../../../../class-helpers/private/create-private-context';
import {
  IsObservableLike,
  TGenericObservableLike,
  TInferObservableLikeGObserver,
} from '../../observable/observable-types';
import { IsObserverLike } from '../../observer/observer-types';
import { ImplTraitToggleForSubscriptionStruct } from '../struct/implementations/subscription-struct-toggle-implementation';
import { ImplTraitGetObservableForSubscriptionStruct } from '../struct/implementations/subscription-struct-get-observable-implementation';
import { ImplTraitGetObserverForSubscriptionStruct } from '../struct/implementations/subscription-struct-get-observer-implementation';
import { ImplTraitIsActivatedForSubscriptionStruct } from '../struct/implementations/subscription-struct-is-activated-implementation';
import { ImplTraitActivateForSubscriptionStruct } from '../struct/implementations/subscription-struct-activate-implementation';
import { ImplTraitDeactivateForSubscriptionStruct } from '../struct/implementations/subscription-struct-deactivate-implementation';

/** CONSTRUCTOR **/

export function ConstructSubscription<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>>(
  instance: ISubscriptionStruct<GObservable, GObserver>,
  observable: GObservable,
  observer: GObserver,
): void {
  if (!IsObservableLike(observable)) {
    throw new TypeError(`The argument 'observable' is not an Observable.`);
  }

  if (!IsObserverLike(observer)) {
    throw new TypeError(`The argument 'observer' is not an Observer.`);
  }

  CreatePrivateContext<ISubscriptionPrivateContext<GObservable, GObserver>>(
    SUBSCRIPTION_PRIVATE_CONTEXT,
    instance,
    {
      observable,
      observer,
      activated: false,
    },
  );
}

/** CLASS **/

export interface ISubscription<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>> extends ISubscriptionStruct<GObservable, GObserver>,
  ImplTraitGetObservableForSubscriptionStruct<ISubscription<GObservable, GObserver>>,
  ImplTraitGetObserverForSubscriptionStruct<ISubscription<GObservable, GObserver>>,
  ImplTraitIsActivatedForSubscriptionStruct<ISubscription<GObservable, GObserver>>,
  ImplTraitActivateForSubscriptionStruct<ISubscription<GObservable, GObserver>>,
  ImplTraitDeactivateForSubscriptionStruct<ISubscription<GObservable, GObserver>>,
  ImplTraitToggleForSubscriptionStruct<ISubscription<GObservable, GObserver>> {
}

export interface IAssembledSubscriptionImplementations {
  new<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>>(): ISubscription<GObservable, GObserver>;
}

export const SubscriptionImplementationsCollection = [
  ImplTraitGetObservableForSubscriptionStruct,
  ImplTraitGetObserverForSubscriptionStruct,
  ImplTraitIsActivatedForSubscriptionStruct,
  ImplTraitActivateForSubscriptionStruct,
  ImplTraitDeactivateForSubscriptionStruct,
  ImplTraitToggleForSubscriptionStruct,
];

const AssembledSubscriptionImplementations = AssembleTraitImplementations<IAssembledSubscriptionImplementations>(SubscriptionImplementationsCollection);

export class Subscription<GObservable extends TGenericObservableLike, GObserver extends TInferObservableLikeGObserver<GObservable>> extends AssembledSubscriptionImplementations<GObservable, GObserver> implements ISubscription<GObservable, GObserver> {
  readonly [SUBSCRIPTION_PRIVATE_CONTEXT]: ISubscriptionPrivateContext<GObservable, GObserver>;

  constructor(
    observable: GObservable,
    observer: GObserver,
  ) {
    super();
    ConstructSubscription<GObservable, GObserver>(this, observable, observer);
  }
}
