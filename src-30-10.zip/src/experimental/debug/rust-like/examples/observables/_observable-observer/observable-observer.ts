import { TGenericObserverLike } from '../observer/observer-types';
import { TGenericObservableLike } from '../observable/observable-types';

// export interface IObservableObserver<GObserver extends TGenericObserverLike, GObservable extends TGenericObservableLike> {
//   readonly observer: GObserver;
//   readonly observable: GObservable;
// }
//
// export type TGenericObservableObserver = IObservableObserver<TGenericObserverLike, TGenericObservableLike>;




