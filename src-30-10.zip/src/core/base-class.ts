export interface IBaseClass {
}

export interface IBaseClassConstructor {
  new(): IBaseClass;
}

export class BaseClass {
}
