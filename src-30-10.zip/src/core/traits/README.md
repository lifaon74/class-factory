#terms

- `derived function` -> function with "extends/override" another
- `method` -> a function with a name to associate with an object
- `trait` -> a collection of method to associate with an object
